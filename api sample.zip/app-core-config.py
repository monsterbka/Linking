import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    API_V1_STR: str = "/api/v1"
    PROJECT_NAME: str = "Trino-Hudi API"
    
    # Cấu hình Trino
    TRINO_HOST: str = os.getenv("TRINO_HOST", "localhost")
    TRINO_PORT: int = int(os.getenv("TRINO_PORT", "8080"))
    TRINO_USER: str = os.getenv("TRINO_USER", "trino")
    TRINO_CATALOG: str = os.getenv("TRINO_CATALOG", "hudi")
    TRINO_SCHEMA: str = os.getenv("TRINO_SCHEMA", "default")
    
    # Cấu hình Spark
    SPARK_MASTER: str = os.getenv("SPARK_MASTER", "local[*]")
    SPARK_APP_NAME: str = os.getenv("SPARK_APP_NAME", "Trino-Hudi API")
    SPARK_HUDI_LOCATION: str = os.getenv("SPARK_HUDI_LOCATION", "/path/to/hudi")
    
    # Cấu hình bảo mật
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your-secret-key-keep-it-secret")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))
    
    # Cấu hình logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
