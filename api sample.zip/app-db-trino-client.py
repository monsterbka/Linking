import trino
import pandas as pd
from app.core.config import settings
from app.core.logging_config import logger

class TrinoClient:
    def __init__(self):
        self.connection = None
        
    def connect(self):
        """Thiết lập kết nối tới Trino server"""
        logger.info(f"Connecting to Trino at {settings.TRINO_HOST}:{settings.TRINO_PORT}")
        try:
            self.connection = trino.dbapi.connect(
                host=settings.TRINO_HOST,
                port=settings.TRINO_PORT,
                user=settings.TRINO_USER,
                catalog=settings.TRINO_CATALOG,
                schema=settings.TRINO_SCHEMA,
            )
            logger.info("Trino connection established")
            return self.connection
        except Exception as e:
            logger.error(f"Failed to connect to Trino: {str(e)}")
            raise
    
    def execute_query(self, query, params=None):
        """Thực thi truy vấn SQL trên Trino"""
        if not self.connection:
            self.connect()
            
        logger.info(f"Executing Trino query: {query}")
        try:
            cursor = self.connection.cursor()
            cursor.execute(query, params)
            columns = [desc[0] for desc in cursor.description] if cursor.description else []
            results = cursor.fetchall()
            
            # Chuyển đổi kết quả sang DataFrame để dễ xử lý
            df = pd.DataFrame(results, columns=columns)
            
            return {
                "columns": columns,
                "data": df.to_dict('records'),
                "row_count": len(df)
            }
        except Exception as e:
            logger.error(f"Error executing Trino query: {str(e)}")
            raise
        
    def list_tables(self, catalog=None, schema=None):
        """Liệt kê các bảng trong catalog và schema"""
        catalog = catalog or settings.TRINO_CATALOG
        schema = schema or settings.TRINO_SCHEMA
        
        query = f"""
        SELECT table_catalog, table_schema, table_name, table_type
        FROM {catalog}.information_schema.tables
        WHERE table_schema = '{schema}'
        ORDER BY table_name
        """
        
        return self.execute_query(query)
    
    def get_table_schema(self, table_name, catalog=None, schema=None):
        """Lấy schema của bảng"""
        catalog = catalog or settings.TRINO_CATALOG
        schema = schema or settings.TRINO_SCHEMA
        
        query = f"""
        SELECT column_name, data_type, is_nullable
        FROM {catalog}.information_schema.columns
        WHERE table_schema = '{schema}'
        AND table_name = '{table_name}'
        ORDER BY ordinal_position
        """
        
        return self.execute_query(query)
    
    def close(self):
        """Đóng kết nối"""
        if self.connection:
            logger.info("Closing Trino connection")
            self.connection.close()
            self.connection = None
