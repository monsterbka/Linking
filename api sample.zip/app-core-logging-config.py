import logging
import sys
from pydantic import ValidationError
from app.core.config import settings

def setup_logging():
    # Lấy log level từ cấu hình
    try:
        log_level = getattr(logging, settings.LOG_LEVEL.upper())
    except (AttributeError, ValidationError):
        log_level = logging.INFO

    # Cấu hình logging cơ bản
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('app.log'),
        ]
    )

    # Tắt những log không cần thiết
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("trino").setLevel(logging.WARNING)
    
    # Trả về logger chính
    return logging.getLogger("trino-hudi-api")

# Tạo logger để sử dụng trong ứng dụng
logger = setup_logging()
