from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from app.core.config import settings
from app.services.query_service import QueryService
from app.db.trino_client import TrinoClient
from app.db.spark_client import SparkClient
from app.models.user_models import User, UserInDB
from app.core.security import get_password_hash
from app.db.hudi_utils import HudiUtils

oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_STR}/auth/token")

# Mô phỏng cơ sở dữ liệu người dùng
fake_users_db = {
    "admin": {
        "username": "admin",
        "full_name": "Administrator",
        "email": "admin@example.com",
        "hashed_password": get_password_hash("adminpassword"),
        "disabled": False,
    },
    "user": {
        "username": "user",
        "full_name": "Normal User",
        "email": "user@example.com",
        "hashed_password": get_password_hash("userpassword"),
        "disabled": False,
    }
}

def get_user(db, username: str):
    if username in db:
        user_dict = db[username]
        return UserInDB(**user_dict)

def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = get_user(fake_users_db, username)
    if user is None:
        raise credentials_exception
    if user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return user

def get_trino_client():
    client = TrinoClient()
    try:
        yield client
    finally:
        client.close()

def get_spark_client():
    client = SparkClient()
    try:
        yield client
    finally:
        client.close()

def get_hudi_utils():
    return HudiUtils()

def get_query_service(
    trino_client: TrinoClient = Depends(get_trino_client),
    spark_client: SparkClient = Depends(get_spark_client),
    hudi_utils: HudiUtils = Depends(get_hudi_utils)
):
    return QueryService(trino_client, spark_client, hudi_utils)
