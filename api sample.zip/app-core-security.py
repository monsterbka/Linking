from datetime import datetime, timedelta
from typing import Optional
from passlib.context import CryptContext
from jose import jwt
from app.core.config import settings
from app.models.user_models import User, UserInDB

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def authenticate_user(username: str, password: str):
    # Đây chỉ là mô phỏng database
    fake_users_db = {
        "admin": {
            "username": "admin",
            "full_name": "Administrator",
            "email": "admin@example.com",
            "hashed_password": get_password_hash("adminpassword"),
            "disabled": False,
        },
        "user": {
            "username": "user",
            "full_name": "Normal User",
            "email": "user@example.com",
            "hashed_password": get_password_hash("userpassword"),
            "disabled": False,
        }
    }
    
    # Kiểm tra nếu mật khẩu đã lưu trữ là đúng
    if username in fake_users_db:
        user_dict = fake_users_db[username]
        stored_hash = user_dict["hashed_password"]
        if verify_password(password, stored_hash):
            return UserInDB(**user_dict)
    return None

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm="HS256")
    return encoded_jwt
