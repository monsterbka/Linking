import time
from app.db.trino_client import TrinoClient
from app.db.spark_client import SparkClient
from app.db.hudi_utils import HudiUtils
from app.core.logging_config import logger

class QueryService:
    def __init__(self, trino_client: TrinoClient, spark_client: SparkClient, hudi_utils: HudiUtils):
        self.trino_client = trino_client
        self.spark_client = spark_client
        self.hudi_utils = hudi_utils
    
    def execute_query(self, query, params=None):
        """Thực thi truy vấn thông qua Trino"""
        start_time = time.time()
        logger.info(f"Executing query through Trino: {query}")
        
        try:
            result = self.trino_client.execute_query(query, params)
            
            # Thêm thời gian thực thi
            execution_time = int((time.time() - start_time) * 1000)  # Chuyển đổi sang ms
            result["execution_time_ms"] = execution_time
            
            logger.info(f"Query executed successfully in {execution_time}ms, returned {result['row_count']} rows")
            return result
        except Exception as e:
            logger.error(f"Error executing query: {str(e)}")
            raise
    
    def execute_spark_query(self, query, options=None):
        """Thực thi truy vấn trực tiếp trên Spark"""
        start_time = time.time()
        logger.info(f"Executing query directly through Spark: {query}")
        
        try:
            result = self.spark_client.execute_query(query, options)
            
            # Thêm thời gian thực thi
            execution_time = int((time.time() - start_time) * 1000)  # Chuyển đổi sang ms
            result["execution_time_ms"] = execution_time
            
            logger.info(f"Spark query executed successfully in {execution_time}ms, returned {result['row_count']} rows")
            return result
        except Exception as e:
            logger.error(f"Error executing Spark query: {str(e)}")
            raise
    
    def list_tables(self, catalog=None, schema=None):
        """Liệt kê các bảng trong Trino"""
        logger.info(f"Listing tables in catalog={catalog}, schema={schema}")
        
        try:
            result = self.trino_client.list_tables(catalog, schema)
            
            # Chuyển đổi kết quả thành TableListResponse
            return {
                "tables": result["data"],
                "count": result["row_count"]
            }
        except Exception as e:
            logger.error(f"Error listing tables: {str(e)}")
            raise
    
    def get_table_schema(self, table_name, catalog=None, schema=None):
        """Lấy schema của bảng trong Trino"""
        logger.info(f"Getting schema for table {table_name} in catalog={catalog}, schema={schema}")
        
        try:
            result = self.trino_client.get_table_schema(table_name, catalog, schema)
            
            # Chuyển đổi kết quả thành TableSchemaResponse
            return {
                "table_name": table_name,
                "columns": result["data"],
                "count": result["row_count"]
            }
        except Exception as e:
            logger.error(f"Error getting table schema: {str(e)}")
            raise
    
    def get_hudi_commits(self, table_name, limit=10):
        """Lấy thông tin commits của bảng Hudi"""
        logger.info(f"Getting commits for Hudi table {table_name}, limit={limit}")
        
        try:
            return self.hudi_utils.get_commits(table_name, limit)
        except Exception as e:
            logger.error(f"Error getting Hudi commits: {str(e)}")
            raise
    
    def list_spark_tables(self, database=None):
        """Liệt kê các bảng trong Spark"""
        logger.info(f"Listing tables in Spark database={database}")
        
        try:
            result = self.spark_client.list_tables(database)
            
            # Chuyển đổi kết quả thành TableListResponse
            return {
                "tables": result["data"],
                "count": result["row_count"]
            }
        except Exception as e:
            logger.error(f"Error listing Spark tables: {str(e)}")
            raise
    
    def compare_hudi_commits(self, table_name, commit1, commit2):
        """So sánh hai commits của bảng Hudi"""
        logger.info(f"Comparing Hudi commits for table {table_name}: {commit1} vs {commit2}")
        
        try:
            return self.hudi_utils.compare_commits(table_name, commit1, commit2)
        except Exception as e:
            logger.error(f"Error comparing Hudi commits: {str(e)}")
            raise
