from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class QueryResponse(BaseModel):
    """Mô hình response cho kết quả truy vấn"""
    columns: List[str] = Field(..., description="Danh sách các cột trong kết quả")
    data: List[Dict[str, Any]] = Field(..., description="Dữ liệu kết quả ở dạng list các dictionary")
    row_count: int = Field(..., description="Số dòng kết quả")
    execution_time_ms: Optional[int] = Field(None, description="Thời gian thực thi truy vấn (ms)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "columns": ["id", "name", "value"],
                "data": [
                    {"id": 1, "name": "Item 1", "value": 100},
                    {"id": 2, "name": "Item 2", "value": 200}
                ],
                "row_count": 2,
                "execution_time_ms": 153
            }
        }

class TableListResponse(BaseModel):
    """Mô hình response cho danh sách bảng"""
    tables: List[Dict[str, str]] = Field(..., description="Danh sách các bảng")
    count: int = Field(..., description="Số lượng bảng")
    
    class Config:
        json_schema_extra = {
            "example": {
                "tables": [
                    {"table_catalog": "hudi", "table_schema": "default", "table_name": "customers", "table_type": "BASE TABLE"},
                    {"table_catalog": "hudi", "table_schema": "default", "table_name": "orders", "table_type": "BASE TABLE"}
                ],
                "count": 2
            }
        }

class TableSchemaResponse(BaseModel):
    """Mô hình response cho schema của bảng"""
    table_name: str = Field(..., description="Tên bảng")
    columns: List[Dict[str, str]] = Field(..., description="Thông tin các cột của bảng")
    count: int = Field(..., description="Số lượng cột")
    
    class Config:
        json_schema_extra = {
            "example": {
                "table_name": "customers",
                "columns": [
                    {"column_name": "id", "data_type": "bigint", "is_nullable": "NO"},
                    {"column_name": "name", "data_type": "varchar", "is_nullable": "YES"},
                    {"column_name": "email", "data_type": "varchar", "is_nullable": "YES"}
                ],
                "count": 3
            }
        }

class HudiCommitsResponse(BaseModel):
    """Mô hình response cho danh sách commits của Hudi"""
    table_name: str = Field(..., description="Tên bảng Hudi")
    commits: List[Dict[str, Any]] = Field(..., description="Danh sách commits")
    count: int = Field(..., description="Số lượng commits")
    
    class Config:
        json_schema_extra = {
            "example": {
                "table_name": "customers",
                "commits": [
                    {"commitTime": "20240225145601", "totalBytes": 1024000, "totalFiles": 5, "action": "COMMIT"},
                    {"commitTime": "20240225135522", "totalBytes": 512000, "totalFiles": 3, "action": "COMMIT"}
                ],
                "count": 2
            }
        }

class ErrorResponse(BaseModel):
    """Mô hình response cho lỗi"""
    detail: str = Field(..., description="Chi tiết lỗi")
    
    class Config:
        json_schema_extra = {
            "example": {
                "detail": "Error executing query: syntax error at position 10"
            }
        }
