from pydantic import BaseModel
from typing import Optional

class Token(BaseModel):
    """Mô hình token đăng nhập"""
    access_token: str
    token_type: str

class TokenData(BaseModel):
    """Mô hình dữ liệu được lưu trong token"""
    username: Optional[str] = None
