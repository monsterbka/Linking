from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List

class QueryRequest(BaseModel):
    """Mô hình request cho truy vấn Trino"""
    query: str = Field(..., description="SQL query để thực thi trên Trino")
    params: Optional[Dict[str, Any]] = Field(None, description="Các tham số truy vấn")
    
    class Config:
        json_schema_extra = {
            "example": {
                "query": "SELECT * FROM hudi.default.sample_table WHERE column1 = 'value' LIMIT 10",
                "params": {"param1": "value1"}
            }
        }

class SparkQueryRequest(BaseModel):
    """Mô hình request cho truy vấn trực tiếp trên Spark"""
    query: str = Field(..., description="SQL query để thực thi trên Spark")
    options: Optional[Dict[str, str]] = Field(None, description="Các tùy chọn Spark")
    
    class Config:
        json_schema_extra = {
            "example": {
                "query": "SELECT * FROM sample_table WHERE column1 = 'value' LIMIT 10",
                "options": {"spark.sql.shuffle.partitions": "10"}
            }
        }

class