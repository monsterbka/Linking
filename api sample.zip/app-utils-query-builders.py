from typing import List, Dict, Any, Optional

class QueryBuilder:
    """Lớp hỗ trợ xây dựng câu truy vấn SQL"""
    
    @staticmethod
    def build_select_query(
        table_name: str,
        columns: Optional[List[str]] = None,
        where_conditions: Optional[Dict[str, Any]] = None,
        group_by: Optional[List[str]] = None,
        having: Optional[str] = None,
        order_by: Optional[List[str]] = None,
        limit: Optional[int] = None,
        catalog: Optional[str] = None,
        schema: Optional[str] = None
    ) -> str:
        """
        Xây dựng câu truy vấn SELECT
        
        Args:
            table_name: Tên bảng
            columns: Danh sách các cột cần lấy
            where_conditions: Điều kiện WHERE (key-value)
            group_by: Các cột nhóm
            having: Điều kiện HAVING
            order_by: Danh sách các cột sắp xếp
            limit: Giới hạn số bản ghi
            catalog: Tên catalog
            schema: Tên schema
        
        Returns:
            Câu truy vấn SQL
        """
        # Xử lý các cột
        columns_str = "*"
        if columns and len(columns) > 0:
            columns_str = ", ".join(columns)
        
        # Xử lý tên bảng đầy đủ
        full_table_name = table_name
        if schema:
            full_table_name = f"{schema}.{full_table_name}"
        if catalog:
            full_table_name = f"{catalog}.{full_table_name}"
        
        # Xây dựng câu truy vấn cơ bản
        query = f"SELECT {columns_str} FROM {full_table_name}"
        
        # Thêm điều kiện WHERE
        if where_conditions and len(where_conditions) > 0:
            conditions = []
            for key, value in where_conditions.items():
                if isinstance(value, str):
                    conditions.append(f"{key} = '{value}'")
                elif value is None:
                    conditions.append(f"{key} IS NULL")
                else:
                    conditions.append(f"{key} = {value}")
            query += " WHERE " + " AND ".join(conditions)
        
        # Thêm GROUP BY
        if group_by and len(group_by) > 0:
            query += " GROUP BY " + ", ".join(group_by)
        
        # Thêm HAVING
        if having:
            query += f" HAVING {having}"
        
        # Thêm ORDER BY
        if order_by and len(order_by) > 0:
            query += " ORDER BY " + ", ".join(order_by)
        
        # Thêm LIMIT
        if limit:
            query += f" LIMIT {limit}"
        
        return query
    
    @staticmethod
    def build_hudi_snapshot_query(
        table_name: str,
        as_of_instant: Optional[str] = None,
        catalog: Optional[str] = None,
        schema: Optional[str] = None
    ) -> str:
        """
        Xây dựng câu truy vấn snapshot cho Hudi
        
        Args:
            table_name: Tên bảng Hudi
            as_of_instant: Thời điểm snapshot
            catalog: Tên catalog
            schema: Tên schema
        
        Returns:
            Câu truy vấn SQL
        """
        # Xử lý tên bảng đầy đủ
        full_table_name = table_name
        if schema:
            full_table_name = f"{schema}.{full_table_name}"
        if catalog:
            full_table_name = f"{catalog}.{full_table_name}"
        
        # Xây dựng câu truy vấn cơ bản
        query = f"SELECT * FROM {full_table_name}"
        
        # Thêm điều kiện thời điểm snapshot
        if as_of_instant:
            query += f" FOR VERSION AS OF '{as_of_instant}'"
        
        return query
    
    @staticmethod
    def build_hudi_incremental_query(
        table_name: str,
        begin_instant: str,
        end_instant: Optional[str] = None,
        catalog: Optional[str] = None,
        schema: Optional[str] = None
    ) -> str:
        """
        Xây dựng câu truy vấn incremental cho Hudi
        
        Args:
            table_name: Tên bảng Hudi
            begin_instant: Thời điểm bắt đầu
            end_instant: Thời điểm kết thúc
            catalog: Tên catalog
            schema: Tên schema
        
        Returns:
            Câu truy vấn SQL
        """
        # Xử lý tên bảng đầy đủ
        full_table_name = table_name
        if schema:
            full_table_name = f"{schema}.{full_table_name}"
        if catalog:
            full_table_name = f"{catalog}.{full_table_name}"
        
        # Xây dựng câu truy vấn cơ bản
        if end_instant:
            query = f"""
            SELECT * FROM {full_table_name}
            FOR SYSTEM_VERSION FROM '{begin_instant}' TO '{end_instant}'
            """
        else:
            query = f"""
            SELECT * FROM {full_table_name}
            FOR SYSTEM_VERSION FROM '{begin_instant}'
            """
        
        return query
    
    @staticmethod
    def build_join_query(
        main_table: str,
        join_tables: List[Dict[str, Any]],
        columns: Optional[List[str]] = None,
        where_conditions: Optional[Dict[str, Any]] = None,
        limit: Optional[int] = None,
        catalog: Optional[str] = None,
        schema: Optional[str] = None
    ) -> str:
        """
        Xây dựng câu truy vấn JOIN
        
        Args:
            main_table: Bảng chính
            join_tables: Danh sách các bảng join kèm điều kiện
                [{"table": "table_name", "type": "INNER", "condition": "t1.id = t2.id"}]
            columns: Danh sách các cột cần lấy
            where_conditions: Điều kiện WHERE (key-value)
            limit: Giới hạn số bản ghi
            catalog: Tên catalog
            schema: Tên schema
        
        Returns:
            Câu truy vấn SQL
        """
        # Xử lý các cột
        columns_str = "*"
        if columns and len(columns) > 0:
            columns_str = ", ".join(columns)
        
        # Xử lý tên bảng đầy đủ
        full_table_name = main_table
        if schema:
            full_table_name = f"{schema}.{full_table_name}"
        if catalog:
            full_table_name = f"{catalog}.{full_table_name}"
        
        # Xây dựng câu truy vấn cơ bản
        query = f"SELECT {columns_str} FROM {full_table_name}"
        
        # Thêm các JOIN
        for join in join_tables:
            join_type = join.get("type", "INNER").upper()
            join_table = join["table"]
            join_condition = join["condition"]
            
            # Xử lý tên bảng join đầy đủ
            full_join_table = join_table
            if schema:
                full_join_table = f"{schema}.{full_join_table}"
            if catalog:
                full_join_table = f"{catalog}.{full_join_table}"
            
            query += f" {join_type} JOIN {full_join_table} ON {join_condition}"
        
        # Thêm điều kiện WHERE
        if where_conditions and len(where_conditions) > 0:
            conditions = []
            for key, value in where_conditions.items():
                if isinstance(value, str):
                    conditions.append(f"{key} = '{value}'")
                elif value is None:
                    conditions.append(f"{key} IS NULL")
                else:
                    conditions.append(f"{key} = {value}")
            query += " WHERE " + " AND ".join(conditions)
        
        # Thêm LIMIT
        if limit:
            query += f" LIMIT {limit}"
        
        return query
