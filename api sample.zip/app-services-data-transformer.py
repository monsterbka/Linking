import pandas as pd
import json
from datetime import datetime
from app.core.logging_config import logger

class DataTransformer:
    def __init__(self):
        """Khởi tạo transformer xử lý dữ liệu"""
        pass
    
    def transform_to_csv(self, query_result):
        """Chuyển đổi kết quả truy vấn sang định dạng CSV"""
        logger.info(f"Transforming query result to CSV format")
        try:
            # Tạo DataFrame từ kết quả
            df = pd.DataFrame(query_result["data"])
            
            # Chuyển đổi sang CSV
            csv_data = df.to_csv(index=False)
            
            return csv_data
        except Exception as e:
            logger.error(f"Error transforming to CSV: {str(e)}")
            raise
    
    def transform_to_json(self, query_result):
        """Chuyển đổi kết quả truy vấn sang định dạng JSON"""
        logger.info(f"Transforming query result to JSON format")
        try:
            # Trả về dữ liệu dạng JSON
            return json.dumps({
                "data": query_result["data"],
                "metadata": {
                    "columns": query_result["columns"],
                    "row_count": query_result["row_count"],
                    "execution_time_ms": query_result.get("execution_time_ms"),
                    "generated_at": datetime.now().isoformat()
                }
            }, default=str)
        except Exception as e:
            logger.error(f"Error transforming to JSON: {str(e)}")
            raise
    
    def transform_to_excel(self, query_result):
        """Chuyển đổi kết quả truy vấn sang định dạng Excel"""
        logger.info(f"Transforming query result to Excel format")
        try:
            # Tạo DataFrame từ kết quả
            df = pd.DataFrame(query_result["data"])
            
            # Tạo buffer để lưu file Excel
            excel_buffer = pd.ExcelWriter("output.xlsx", engine="xlsxwriter")
            df.to_excel(excel_buffer, sheet_name="Data", index=False)
            
            # Thêm sheet metadata
            metadata = pd.DataFrame([{
                "Column Count": len(query_result["columns"]),
                "Row Count": query_result["row_count"],
                "Execution Time (ms)": query_result.get("execution_time_ms", "N/A"),
                "Generated At": datetime.now().isoformat()
            }])
            metadata.to_excel(excel_buffer, sheet_name="Metadata", index=False)
            
            # Lưu và đóng buffer
            excel_buffer.close()
            
            # Trong thực tế, bạn sẽ trả về file_content
            # nhưng ở đây chúng ta chỉ mô phỏng
            return "Excel file content would be returned here"
        except Exception as e:
            logger.error(f"Error transforming to Excel: {str(e)}")
            raise
    
    def filter_columns(self, query_result, columns):
        """Lọc chỉ giữ lại một số cột nhất định"""
        logger.info(f"Filtering columns: {columns}")
        try:
            # Tạo DataFrame từ kết quả
            df = pd.DataFrame(query_result["data"])
            
            # Chỉ giữ lại các cột được chỉ định
            available_columns = set(df.columns)
            columns_to_keep = [col for col in columns if col in available_columns]
            
            if not columns_to_keep:
                raise ValueError("None of the specified columns exist in the data")
                
            filtered_df = df[columns_to_keep]
            
            # Cập nhật kết quả
            return {
                "columns": columns_to_keep,
                "data": filtered_df.to_dict('records'),
                "row_count": len(filtered_df),
                "execution_time_ms": query_result.get("execution_time_ms")
            }
        except Exception as e:
            logger.error(f"Error filtering columns: {str(e)}")
            raise
    
    def aggregate_data(self, query_result, group_by, agg_funcs):
        """Thực hiện tổng hợp dữ liệu theo nhóm"""
        logger.info(f"Aggregating data by {group_by} with functions {agg_funcs}")
        try:
            # Tạo DataFrame từ kết quả
            df = pd.DataFrame(query_result["data"])
            
            # Thực hiện tổng hợp
            grouped = df.groupby(group_by).agg(agg_funcs).reset_index()
            
            # Cập nhật kết quả
            return {
                "columns": grouped.columns.tolist(),
                "data": grouped.to_dict('records'),
                "row_count": len(grouped),
                "execution_time_ms": query_result.get("execution_time_ms")
            }
        except Exception as e:
            logger.error(f"Error aggregating data: {str(e)}")
            raise
