import os
import pandas as pd
import subprocess
import json
from app.core.config import settings
from app.core.logging_config import logger

class HudiUtils:
    def __init__(self):
        # Các thông tin cần thiết để tương tác với công cụ Hudi CLI
        self.hudi_base_path = settings.SPARK_HUDI_LOCATION
        
    def get_commits(self, table_name, limit=10):
        """Lấy thông tin về các commits của bảng Hudi"""
        logger.info(f"Getting commits for Hudi table: {table_name}, limit: {limit}")
        try:
            # Đường dẫn đến bảng Hudi
            table_path = os.path.join(self.hudi_base_path, table_name)
            
            # Sử dụng Hudi CLI thông qua subprocess để lấy thông tin commits
            # Đây là cách mô phỏng, trong thực tế bạn cần cài đặt Hudi CLI
            # và đưa ra lệnh chính xác
            cmd = [
                "java", "-cp", "path-to-hudi-cli-with-dependencies.jar",
                "org.apache.hudi.cli.Main",
                "commits", "show", "--path", table_path, "--limit", str(limit)
            ]
            
            # Mô phỏng kết quả trả về
            # Trong thực tế, bạn sẽ chạy cmd và lấy kết quả
            # result = subprocess.run(cmd, capture_output=True, text=True)
            # commits_data = parse_hudi_cli_output(result.stdout)
            
            # Mô phỏng dữ liệu
            commits_data = [
                {"commitTime": "20240225145601", "totalBytes": 1024000, "totalFiles": 5, "action": "COMMIT"},
                {"commitTime": "20240225135522", "totalBytes": 512000, "totalFiles": 3, "action": "COMMIT"},
                {"commitTime": "20240225125102", "totalBytes": 256000, "totalFiles": 2, "action": "COMMIT"},
                {"commitTime": "20240225115230", "totalBytes": 128000, "totalFiles": 1, "action": "COMMIT"}
            ]
            
            return {
                "table_name": table_name,
                "commits": commits_data,
                "count": len(commits_data)
            }
            
        except Exception as e:
            logger.error(f"Error getting Hudi commits: {str(e)}")
            raise
            
    def get_table_metadata(self, table_name):
        """Lấy metadata của bảng Hudi"""
        logger.info(f"Getting metadata for Hudi table: {table_name}")
        try:
            # Đường dẫn đến bảng Hudi
            table_path = os.path.join(self.hudi_base_path, table_name)
            
            # Mô phỏng dữ liệu
            metadata = {
                "table_name": table_name,
                "base_path": table_path,
                "table_type": "COPY_ON_WRITE",  # hoặc MERGE_ON_READ
                "partition_fields": ["year", "month", "day"],
                "record_key_fields": ["id"],
                "preCombine_field": "ts",
                "total_commits": 42,
                "total_files": 128,
                "total_size_bytes": 1024000000
            }
            
            return metadata
            
        except Exception as e:
            logger.error(f"Error getting Hudi table metadata: {str(e)}")
            raise
            
    def compare_commits(self, table_name, commit1, commit2):
        """So sánh hai commits"""
        logger.info(f"Comparing commits for table {table_name}: {commit1} vs {commit2}")
        try:
            # Mô phỏng dữ liệu
            diff_data = {
                "table_name": table_name,
                "base_commit": commit1,
                "target_commit": commit2,
                "added_files": 5,
                "modified_files": 3,
                "deleted_files": 1,
                "added_records": 1000,
                "modified_records": 500,
                "deleted_records": 100
            }
            
            return diff_data
            
        except Exception as e:
            logger.error(f"Error comparing Hudi commits: {str(e)}")
            raise
