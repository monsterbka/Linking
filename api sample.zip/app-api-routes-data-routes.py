from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional, List

from app.models.request_models import QueryRequest, SparkQueryRequest
from app.models.response_models import QueryResponse
from app.services.query_service import QueryService
from app.api.dependencies import get_query_service, get_current_user
from app.models.user_models import User

router = APIRouter(prefix="/data", tags=["data"])

@router.post("/query", response_model=QueryResponse)
async def execute_query(
    query_request: QueryRequest,
    query_service: QueryService = Depends(get_query_service),
    current_user: User = Depends(get_current_user)
):
    """Endpoint để thực thi truy vấn dữ liệu Hudi qua Trino"""
    try:
        result = query_service.execute_query(
            query=query_request.query,
            params=query_request.params
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/spark/query", response_model=QueryResponse)
async def execute_spark_query(
    query_request: SparkQueryRequest,
    query_service: QueryService = Depends(get_query_service),
    current_user: User = Depends(get_current_user)
):
    """Endpoint để thực thi truy vấn trực tiếp vào Spark"""
    try:
        result = query_service.execute_spark_query(
            query=query_request.query,
            options=query_request.options
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/tables")
async def list_tables(
    catalog: Optional[str] = Query(None, description="Tên catalog"),
    schema: Optional[str] = Query(None, description="Tên schema"),
    query_service: QueryService = Depends(get_query_service),
    current_user: User = Depends(get_current_user)
):
    """Liệt kê các bảng Hudi có sẵn"""
    try:
        return query_service.list_tables(catalog, schema)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/tables/{table_name}/schema")
async def get_table_schema(
    table_name: str,
    catalog: Optional[str] = Query(None, description="Tên catalog"),
    schema: Optional[str] = Query(None, description="Tên schema"),
    query_service: QueryService = Depends(get_query_service),
    current_user: User = Depends(get_current_user)
):
    """Lấy schema của bảng Hudi"""
    try:
        return query_service.get_table_schema(table_name, catalog, schema)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/hudi/{table_name}/commits")
async def get_hudi_commits(
    table_name: str,
    limit: int = Query(10, description="Số lượng commits tối đa"),
    query_service: QueryService = Depends(get_query_service),
    current_user: User = Depends(get_current_user)
):
    """Lấy danh sách commits gần nhất của bảng Hudi"""
    try:
        return query_service.get_hudi_commits(table_name, limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/spark/tables")
async def list_spark_tables(
    database: Optional[str] = Query(None, description="Tên database trong Spark"),
    query_service: QueryService = Depends(get_query_service),
    current_user: User = Depends(get_current_user)
):
    """Liệt kê các bảng trong Spark"""
    try:
        return query_service.list_spark_tables(database)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
