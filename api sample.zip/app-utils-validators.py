import re
from typing import Optional, List, Dict, Any

class SQLValidator:
    """Lớp hỗ trợ kiểm tra và kiểm duyệt câu truy vấn SQL"""
    
    # Danh sách các từ khóa nguy hiểm
    DANGEROUS_KEYWORDS = [
        'DROP', 'DELETE', 'TRUNCATE', 'ALTER', 'CREATE', 'INSERT', 'UPDATE',
        'GRANT', 'REVOKE', 'EXECUTE', 'SHUTDOWN', 'KILL'
    ]
    
    # Những kiểu truy vấn được phép
    ALLOWED_QUERY_TYPES = ['SELECT', 'WITH', 'SHOW', 'DESCRIBE', 'EXPLAIN']
    
    @staticmethod
    def is_safe_query(query: str) -> bool:
        """
        Kiểm tra xem truy vấn có an toàn không
        
        Args:
            query: Câu truy vấn SQL
        
        Returns:
            True nếu câu truy vấn an toàn, False nếu nguy hiểm
        """
        # Normalize query: loại bỏ comments, whitespace, chuyển về chữ hoa
        normalized_query = SQLValidator._normalize_query(query)
        
        # Kiểm tra xem truy vấn bắt đầu bằng một loại được phép không
        if not any(normalized_query.startswith(qt) for qt in SQLValidator.ALLOWED_QUERY_TYPES):
            return False
        
        # Kiểm tra có chứa từ khóa nguy hiểm không
        if any(f" {kw} " in f" {normalized_query} " for kw in SQLValidator.DANGEROUS_KEYWORDS):
            return False
        
        # Kiểm tra injection