from pydantic import BaseModel, EmailStr, Field
from typing import Optional

class User(BaseModel):
    """Mô hình thông tin người dùng cơ bản"""
    username: str
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    disabled: Optional[bool] = None

class UserInDB(User):
    """Mô hình mở rộng với thông tin lưu trữ trong DB"""
    hashed_password: str

class UserCreate(BaseModel):
    """Mô hình cho việc tạo người dùng mới"""
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    full_name: Optional[str] = None
    password: str = Field(..., min_length=8)
    
    class Config:
        json_schema_extra = {
            "example": {
                "username": "newuser",
                "email": "user@example.com",
                "full_name": "New User",
                "password": "securepassword123"
            }
        }

class UserUpdate(BaseModel):
    """Mô hình cho việc cập nhật thông tin người dùng"""
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    password: Optional[str] = Field(None, min_length=8)
    disabled: Optional[bool] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "email": "updated@example.com",
                "full_name": "Updated Name",
                "password": "newsecurepassword123"
            }
        }
