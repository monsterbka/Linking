import os
import pandas as pd
from pyspark.sql import SparkSession
from app.core.config import settings
from app.core.logging_config import logger

class SparkClient:
    def __init__(self):
        self.spark = None
        
    def connect(self):
        """Khởi tạo Spark session"""
        if self.spark:
            return self.spark
            
        logger.info(f"Initializing Spark session with master: {settings.SPARK_MASTER}")
        try:
            # Cài đặt thư viện Hudi
            os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages org.apache.hudi:hudi-spark-bundle_2.12:0.12.2 pyspark-shell'
            
            self.spark = (SparkSession.builder
                .appName(settings.SPARK_APP_NAME)
                .master(settings.SPARK_MASTER)
                .config("spark.sql.extensions", "org.apache.spark.sql.hudi.HoodieSparkSessionExtension")
                .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .getOrCreate())
            
            logger.info("Spark session initialized")
            return self.spark
        except Exception as e:
            logger.error(f"Failed to initialize Spark session: {str(e)}")
            raise
    
    def execute_query(self, query, options=None):
        """Thực thi truy vấn SQL trực tiếp trên Spark"""
        if not self.spark:
            self.connect()
            
        logger.info(f"Executing Spark SQL query: {query}")
        try:
            # Áp dụng các tùy chọn nếu có
            if options and isinstance(options, dict):
                for key, value in options.items():
                    self.spark.conf.set(key, value)
            
            # Thực thi truy vấn
            result_df = self.spark.sql(query)
            
            # Chuyển đổi kết quả thành định dạng có thể serialize
            pdf = result_df.toPandas()
            columns = pdf.columns.tolist()
            
            return {
                "columns": columns,
                "data": pdf.to_dict('records'),
                "row_count": len(pdf)
            }
        except Exception as e:
            logger.error(f"Error executing Spark query: {str(e)}")
            raise
    
    def read_hudi_table(self, table_path, query_type="snapshot"):
        """Đọc bảng Hudi với các kiểu truy vấn khác nhau"""
        if not self.spark:
            self.connect()
            
        logger.info(f"Reading Hudi table at {table_path} with query type: {query_type}")
        try:
            # Xác định kiểu truy vấn Hudi (snapshot, incremental, read_optimized)
            read_options = {}
            
            if query_type == "snapshot":
                read_options["hoodie.datasource.query.type"] = "snapshot"
            elif query_type == "incremental":
                read_options["hoodie.datasource.query.type"] = "incremental"
                # Cần thêm thông tin query từ thời điểm bắt đầu
                # read_options["hoodie.datasource.read.begin.instanttime"] = begin_time
            elif query_type == "read_optimized":
                read_options["hoodie.datasource.query.type"] = "read_optimized"
            
            # Đọc dữ liệu Hudi
            hudi_df = self.spark.read.format("hudi").options(**read_options).load(table_path)
            
            return hudi_df
        except Exception as e:
            logger.error(f"Error reading Hudi table: {str(e)}")
            raise
    
    def list_tables(self, database=None):
        """Liệt kê các bảng trong Spark"""
        if not self.spark:
            self.connect()
        
        try:
            if database:
                self.spark.sql(f"USE {database}")
                
            tables_df = self.spark.sql("SHOW TABLES")
            return {
                "columns": tables_df.columns,
                "data": tables_df.toPandas().to_dict('records'),
                "row_count": tables_df.count()
            }
        except Exception as e:
            logger.error(f"Error listing Spark tables: {str(e)}")
            raise
    
    def close(self):
        """Đóng Spark session"""
        if self.spark:
            logger.info("Stopping Spark session")
            self.spark.stop()
            self.spark = None
