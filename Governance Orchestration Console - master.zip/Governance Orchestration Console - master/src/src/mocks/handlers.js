import { http, HttpResponse } from 'msw'

// ── Mock data ──────────────────────────────────────────────
const eventsData = [
  { id: 1, event_id: 'EVT-001', entity_type: 'created', event_type: 'table', sync_type: 'webhook', event_time: '2026-03-28T08:12:00Z', sync_time: '2026-03-28T08:12:05Z', status: 'success' },
  { id: 2, event_id: 'EVT-002', entity_type: 'updated', event_type: 'tag', sync_type: 'webhook', event_time: '2026-03-28T08:30:00Z', sync_time: '2026-03-28T08:30:03Z', status: 'success' },
  { id: 3, event_id: 'EVT-003', entity_type: 'deleted', event_type: 'table', sync_type: 'webhook', event_time: '2026-03-28T09:00:00Z', sync_time: '2026-03-28T09:00:08Z', status: 'running' },
  { id: 4, event_id: 'EVT-004', entity_type: 'created', event_type: 'tag', sync_type: 'reconcile', event_time: '2026-03-28T09:15:00Z', sync_time: '2026-03-28T09:15:12Z', status: 'success' },
  { id: 5, event_id: 'EVT-005', entity_type: 'deleted', event_type: 'tag', sync_type: 'reconcile', event_time: '2026-03-28T09:45:00Z', sync_time: '2026-03-28T09:45:10Z', status: 'running' },
  { id: 6, event_id: 'EVT-006', entity_type: 'updated', event_type: 'table', sync_type: 'webhook', event_time: '2026-03-28T10:00:00Z', sync_time: '2026-03-28T10:00:02Z', status: 'success' },
  { id: 7, event_id: 'EVT-007', entity_type: 'created', event_type: 'table', sync_type: 'webhook', event_time: '2026-03-28T10:30:00Z', sync_time: '2026-03-28T10:30:04Z', status: 'success' },
  { id: 8, event_id: 'EVT-008', entity_type: 'updated', event_type: 'tag', sync_type: 'reconcile', event_time: '2026-03-28T11:00:00Z', sync_time: '2026-03-28T11:00:15Z', status: 'running' },
  { id: 9, event_id: 'EVT-009', entity_type: 'created', event_type: 'tag', sync_type: 'webhook', event_time: '2026-03-28T11:30:00Z', sync_time: '2026-03-28T11:30:01Z', status: 'success' },
  { id: 10, event_id: 'EVT-010', entity_type: 'deleted', event_type: 'table', sync_type: 'reconcile', event_time: '2026-03-28T12:00:00Z', sync_time: '2026-03-28T12:00:20Z', status: 'running' },
  { id: 11, event_id: 'EVT-011', entity_type: 'updated', event_type: 'table', sync_type: 'webhook', event_time: '2026-03-27T14:00:00Z', sync_time: '2026-03-27T14:00:03Z', status: 'success' },
  { id: 12, event_id: 'EVT-012', entity_type: 'created', event_type: 'tag', sync_type: 'reconcile', event_time: '2026-03-27T15:30:00Z', sync_time: '2026-03-27T15:30:09Z', status: 'success' },
]

const reconcileData = [
  { id: 1, job_time: '2026-03-28T06:00:00Z', duration: 95, status: 'success', job_type: 'schedule', is_matched: true, sync_mismatch_duration: 0, sync_mismatch_status: 'success', metadata: [] },
  { id: 2, job_time: '2026-03-28T08:00:00Z', duration: 120, status: 'success', job_type: 'schedule', is_matched: true, sync_mismatch_duration: 0, sync_mismatch_status: 'success', metadata: [] },
  { id: 3, job_time: '2026-03-28T10:00:00Z', duration: 180, status: 'failed', job_type: 'schedule', is_matched: false, sync_mismatch_duration: 45, sync_mismatch_status: 'failed', metadata: [{ type: 'table', table: 'db.schema.orders', columns: 'price,qty', tag: 'PII' }, { type: 'tag', table: 'db.schema.users', columns: 'email', tag: 'Sensitive' }] },
  { id: 4, job_time: '2026-03-28T12:00:00Z', duration: 85, status: 'success', job_type: 'manual', is_matched: true, sync_mismatch_duration: 0, sync_mismatch_status: 'success', metadata: [] },
  { id: 5, job_time: '2026-03-28T14:00:00Z', duration: 210, status: 'failed', job_type: 'schedule', is_matched: false, sync_mismatch_duration: 90, sync_mismatch_status: 'running', metadata: [{ type: 'columns', table: 'db.analytics.events', columns: 'user_id,session_id', tag: 'Internal' }, { type: 'table', table: 'db.public.products', columns: 'name', tag: 'Public' }, { type: 'tag', table: 'db.schema.accounts', columns: 'balance', tag: 'PII' }] },
  { id: 6, job_time: '2026-03-28T16:00:00Z', duration: 150, status: 'running', job_type: 'manual', is_matched: false, sync_mismatch_duration: 0, sync_mismatch_status: 'running', metadata: [] },
  { id: 7, job_time: '2026-03-27T06:00:00Z', duration: 100, status: 'success', job_type: 'schedule', is_matched: true, sync_mismatch_duration: 0, sync_mismatch_status: 'success', metadata: [] },
  { id: 8, job_time: '2026-03-27T10:00:00Z', duration: 140, status: 'success', job_type: 'schedule', is_matched: false, sync_mismatch_duration: 15, sync_mismatch_status: 'success', metadata: [{ type: 'tag', table: 'db.warehouse.inventory', columns: 'stock_level', tag: 'Confidential' }] },
  { id: 9, job_time: '2026-03-27T14:00:00Z', duration: 200, status: 'failed', job_type: 'manual', is_matched: false, sync_mismatch_duration: 120, sync_mismatch_status: 'failed', metadata: [{ type: 'table', table: 'db.reporting.daily_stats', columns: 'revenue,cost', tag: 'Finance' }, { type: 'columns', table: 'db.hr.employees', columns: 'salary,ssn', tag: 'PII' }] },
  { id: 10, job_time: '2026-03-27T18:00:00Z', duration: 110, status: 'success', job_type: 'schedule', is_matched: true, sync_mismatch_duration: 0, sync_mismatch_status: 'success', metadata: [] },
]

const eventsReconcileData = [
  { id: 1, job_time: '2026-03-28T06:00:00Z', duration: 85, status: 'success', job_type: 'schedule', is_matched: true, metadata: '' },
  { id: 2, job_time: '2026-03-28T08:00:00Z', duration: 110, status: 'success', job_type: 'schedule', is_matched: true, metadata: '' },
  { id: 3, job_time: '2026-03-28T10:00:00Z', duration: 160, status: 'success', job_type: 'schedule', is_matched: false, metadata: '[2026-03-28 10:01:12] ERROR: EVT-003 table.deleted - Ranger policy not found for entity "db.schema.table_1"\n[2026-03-28 10:02:45] ERROR: EVT-010 table.deleted - Timeout syncing to Ranger after 30s\n[2026-03-28 10:02:46] INFO: Reconcile completed with 2 mismatches' },
  { id: 4, job_time: '2026-03-28T12:00:00Z', duration: 75, status: 'success', job_type: 'manual', is_matched: true, metadata: '' },
  { id: 5, job_time: '2026-03-28T14:00:00Z', duration: 190, status: 'success', job_type: 'schedule', is_matched: false, metadata: '[2026-03-28 14:01:05] ERROR: EVT-005 tag.deleted - Tag mapping mismatch between OM and Ranger\n[2026-03-28 14:02:30] ERROR: EVT-008 tag.updated - Ranger service unavailable (HTTP 503)\n[2026-03-28 14:03:10] ERROR: EVT-010 table.deleted - Sync conflict detected, manual resolution required\n[2026-03-28 14:03:11] INFO: Reconcile completed with 3 mismatches' },
  { id: 6, job_time: '2026-03-28T16:00:00Z', duration: 130, status: 'running', job_type: 'manual', is_matched: null, metadata: '' },
  { id: 7, job_time: '2026-03-27T06:00:00Z', duration: 90, status: 'success', job_type: 'schedule', is_matched: true, metadata: '' },
  { id: 8, job_time: '2026-03-27T10:00:00Z', duration: 145, status: 'success', job_type: 'schedule', is_matched: false, metadata: '[2026-03-27 10:02:00] ERROR: EVT-011 table.updated - Permission denied on Ranger policy update\n[2026-03-27 10:02:01] INFO: Reconcile completed with 1 mismatch' },
  { id: 9, job_time: '2026-03-27T14:00:00Z', duration: 220, status: 'running', job_type: 'manual', is_matched: null, metadata: '' },
  { id: 10, job_time: '2026-03-27T18:00:00Z', duration: 100, status: 'success', job_type: 'schedule', is_matched: true, metadata: '' },
]

// ── Pagination helper ───────────────────────
const paginate = (data, url) => {
  const page = parseInt(url.searchParams.get('page') || '1', 10)
  const pageSize = parseInt(url.searchParams.get('pageSize') || '10', 10)
  const totalRecords = data.length
  const totalPages = Math.max(1, Math.ceil(totalRecords / pageSize))
  const start = (page - 1) * pageSize
  const items = data.slice(start, start + pageSize)
  return { data: items, page, pageSize, totalRecords, totalPages }
}

export const handlers = [
  // ── Login ─────────────────────────────────
  http.post('/api/login', async ({ request }) => {
    const { username } = await request.json()
    const users = {
      admin: { name: 'Admin', role: 'admin', permissions: ['events', 'events-reconcile', 'metadata-reconcile'] },
      viewer: { name: 'Viewer', role: 'viewer', permissions: ['events'] },
      operator: { name: 'Operator', role: 'operator', permissions: ['events', 'events-reconcile'] },
    }
    const user = users[username]
    if (!user) return HttpResponse.json({ error: 'Invalid credentials' }, { status: 401 })
    return HttpResponse.json({ token: 'mock-token', user })
  }),

  // ── Events ────────────────────────────────
  http.get('/api/events', ({ request }) => {
    const url = new URL(request.url)
    let result = [...eventsData]

    const entityType = url.searchParams.get('entity_type')
    const eventType = url.searchParams.get('event_type')
    const syncType = url.searchParams.get('sync_type')
    const status = url.searchParams.get('status')
    const syncTimeFrom = url.searchParams.get('sync_time_from')
    const syncTimeTo = url.searchParams.get('sync_time_to')

    if (entityType) result = result.filter(e => e.entity_type === entityType)
    if (eventType) result = result.filter(e => e.event_type === eventType)
    if (syncType) result = result.filter(e => e.sync_type === syncType)
    if (status) result = result.filter(e => e.status === status)
    if (syncTimeFrom) result = result.filter(e => e.sync_time >= syncTimeFrom)
    if (syncTimeTo) result = result.filter(e => e.sync_time <= syncTimeTo)

    return HttpResponse.json(paginate(result, url))
  }),

  // ── Metadata Reconcile ────────────────────
  http.get('/api/metadata-reconcile', ({ request }) => {
    const url = new URL(request.url)
    let result = [...reconcileData]

    const status = url.searchParams.get('status')
    const isMatched = url.searchParams.get('is_matched')
    const jobTimeFrom = url.searchParams.get('job_time_from')
    const jobTimeTo = url.searchParams.get('job_time_to')

    if (status) result = result.filter(r => r.status === status)
    if (isMatched !== null && isMatched !== '') result = result.filter(r => String(r.is_matched) === isMatched)
    if (jobTimeFrom) result = result.filter(r => r.job_time >= jobTimeFrom)
    if (jobTimeTo) result = result.filter(r => r.job_time <= jobTimeTo)

    const paginated = paginate(result, url)
    paginated.data = paginated.data.map(({ metadata, ...rest }) => rest)
    return HttpResponse.json(paginated)
  }),

  http.get('/api/metadata-reconcile/:id/metadata', ({ params }) => {
    const item = reconcileData.find(r => r.id === Number(params.id))
    if (!item) return HttpResponse.json({ error: 'Not found' }, { status: 404 })
    return HttpResponse.json({ id: item.id, metadata: item.metadata })
  }),

  http.post('/api/metadata-reconcile/force', () => {
    return HttpResponse.json({ message: 'Force đối soát thành công' })
  }),

  // ── Events Reconcile ──────────────────────
  http.get('/api/events-reconcile', ({ request }) => {
    const url = new URL(request.url)
    let result = [...eventsReconcileData]

    const status = url.searchParams.get('status')
    const isMatched = url.searchParams.get('is_matched')
    const jobTimeFrom = url.searchParams.get('job_time_from')
    const jobTimeTo = url.searchParams.get('job_time_to')

    if (status) result = result.filter(r => r.status === status)
    if (isMatched !== null && isMatched !== '') result = result.filter(r => String(r.is_matched) === isMatched)
    if (jobTimeFrom) result = result.filter(r => r.job_time >= jobTimeFrom)
    if (jobTimeTo) result = result.filter(r => r.job_time <= jobTimeTo)

    // Exclude metadata from list response
    const paginated = paginate(result, url)
    paginated.data = paginated.data.map(({ metadata, ...rest }) => rest)
    return HttpResponse.json(paginated)
  }),

  http.get('/api/events-reconcile/:id/metadata', ({ params }) => {
    const item = eventsReconcileData.find(r => r.id === Number(params.id))
    if (!item) return HttpResponse.json({ error: 'Not found' }, { status: 404 })
    return HttpResponse.json({ id: item.id, metadata: item.metadata })
  }),

  http.post('/api/events-reconcile/force', async () => {
    return HttpResponse.json({ message: 'Đã gửi yêu cầu force đối soát thành công' });
  }),
]
