import EventsPage from '../pages/EventsPage';
import ReconcilePage from '../pages/ReconcilePage';
import EventsReconcilePage from '../pages/EventsReconcilePage';

/**
 * Module registry — khai báo tập trung tất cả module trong hệ thống.
 *
 * Để thêm module mới, chỉ cần thêm 1 object vào mảng này với đầy đủ các trường:
 *   - id:         Định danh duy nhất, dùng cho permission check
 *   - path:       Đường dẫn route (React Router)
 *   - label:      Tên hiển thị trên sidebar
 *   - icon:       Material Symbols icon name
 *   - component:  React component render trang
 *
 * Sau đó bổ sung:
 *   1. Mock handler tương ứng trong mocks/handlers/ (hoặc handlers.js)
 *   2. Thêm permission id vào danh sách users trong mock login handler
 */
const modules = [
  {
    id: 'events',
    path: '/events',
    label: 'Sự kiện',
    icon: 'event',
    component: EventsPage,
  },
  {
    id: 'events-reconcile',
    path: '/events-reconcile',
    label: 'Đối soát sự kiện',
    icon: 'rule',
    component: EventsReconcilePage,
  },
  {
    id: 'metadata-reconcile',
    path: '/metadata-reconcile',
    label: 'Đối soát dữ liệu',
    icon: 'account_balance_wallet',
    component: ReconcilePage,
  },
];

export default modules;
