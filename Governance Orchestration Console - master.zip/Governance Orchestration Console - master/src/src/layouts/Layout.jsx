import React, { useState } from 'react';
import Header from './Header';
import Sidebar from './Sidebar';

const Layout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="h-screen overflow-hidden bg-surface text-on-surface antialiased">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <Header onMenuToggle={() => setSidebarOpen(o => !o)} />

      {/* Main content */}
      <main className="lg:ml-64 pt-16 h-screen flex flex-col overflow-hidden">
        <div className="flex-1 min-h-0 flex flex-col p-6">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
