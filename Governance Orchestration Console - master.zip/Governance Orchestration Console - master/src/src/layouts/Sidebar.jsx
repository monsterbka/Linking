import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import modules from '../config/modules';

const systemItems = [
  { to: '#', icon: 'settings', label: 'Cài đặt' },
  { to: '#', icon: 'help', label: 'Trợ giúp' },
];

const roleLabels = {
  admin: 'Quản trị viên',
  viewer: 'Người xem',
  operator: 'Vận hành viên',
};

const Sidebar = ({ open, onClose }) => {
  const location = useLocation();
  const { user, hasPermission } = useAuth();

  const initials = (user?.name || 'A').charAt(0).toUpperCase();
  const navItems = modules.filter(m => hasPermission(m.id));

  return (
    <>
      {/* Overlay for mobile */}
      {open && (
        <div className="fixed inset-0 z-30 bg-black/30 lg:hidden" onClick={onClose} />
      )}
      <aside className={`fixed left-0 top-0 bottom-0 z-40 w-64 h-screen bg-slate-50 border-r-0 text-sm font-medium leading-none transition-transform duration-200 ease-in-out lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex flex-col h-full">
        {/* Brand */}
        <div className="px-6 h-16 flex flex-col justify-center border-b border-slate-200/10">
          <div className="text-lg font-bold tracking-tight text-blue-800 flex items-center gap-2">
            <span className="material-symbols-outlined text-2xl">account_tree</span>
            Governance Console
          </div>
          <div className="text-[10px] uppercase tracking-[0.1em] text-slate-400 font-semibold leading-none">
            Orchestration Ledger
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 mt-4 space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`relative flex items-center px-4 py-3 transition-colors duration-150 ease-in-out active:scale-95 transform ${
                  isActive
                    ? 'text-blue-700 before:absolute before:left-0 before:w-0.5 before:h-6 before:bg-blue-700'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <span className="material-symbols-outlined mr-3">{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            );
          })}

          <div className="pt-8 pb-2 px-4">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">System</span>
          </div>

          {systemItems.map((item) => (
            <a
              key={item.label}
              href={item.to}
              className="flex items-center px-4 py-3 text-slate-500 hover:text-slate-900 transition-colors duration-150 ease-in-out active:scale-95 transform"
            >
              <span className="material-symbols-outlined mr-3">{item.icon}</span>
              <span>{item.label}</span>
            </a>
          ))}
        </nav>

        {/* User Footer */}
        <div className="p-4 bg-slate-100 m-4 rounded-xl">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-primary-container flex items-center justify-center text-primary font-bold">
              {initials}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-900 truncate">{user?.name || 'Admin'}</p>
              <p className="text-[10px] text-slate-500 truncate">{roleLabels[user?.role] || user?.role || 'Không xác định'}</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
    </>
  );
};

export default Sidebar;
