import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const roleLabels = {
  admin: 'Quản trị viên',
  viewer: 'Người xem',
  operator: 'Vận hành viên',
};

const Header = ({ onMenuToggle }) => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const initials = (user?.name || 'A').charAt(0).toUpperCase();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="fixed top-0 right-0 left-0 lg:left-64 z-50 h-16 bg-white/85 backdrop-blur-md shadow-sm border-b border-slate-200/15 flex items-center justify-between px-6">
      <div className="flex items-center gap-4">
        <button onClick={onMenuToggle} className="lg:hidden p-1.5 -ml-1 text-slate-500 hover:bg-slate-100 rounded-lg transition-colors">
          <span className="material-symbols-outlined">menu</span>
        </button>
        <h1 className="text-xl font-bold text-slate-900">Trang quản trị</h1>
      </div>

      <div className="flex items-center gap-2 sm:gap-4 overflow-hidden">
        {/* Action Icons */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button className="p-2 text-slate-500 hover:bg-slate-100/50 rounded-lg transition-all duration-200 ease-in-out relative">
            <span className="material-symbols-outlined">notifications</span>
            <span className="absolute top-2 right-2 w-2 h-2 bg-error rounded-full border-2 border-white"></span>
          </button>
          <button className="p-2 text-slate-500 hover:bg-slate-100/50 rounded-lg transition-all duration-200 ease-in-out">
            <span className="material-symbols-outlined">settings</span>
          </button>
        </div>

        <div className="h-6 w-px bg-slate-200/50 mx-1"></div>

        {/* Profile & Logout */}
        <div className="flex items-center gap-3 flex-shrink-0">
          <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
            <div className="text-right hidden sm:block">
              <span className="block text-sm font-medium text-slate-700">{user?.name || 'Admin'}</span>
              <span className="block text-[10px] text-slate-400">{roleLabels[user?.role] || user?.role}</span>
            </div>
            <div className="w-8 h-8 rounded-full bg-primary-container flex items-center justify-center text-on-primary-container font-bold text-xs">
              {initials}
            </div>
            <button
              onClick={handleLogout}
              className="text-sm text-slate-500 hover:text-slate-900 transition-colors"
            >
              Đăng xuất
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
