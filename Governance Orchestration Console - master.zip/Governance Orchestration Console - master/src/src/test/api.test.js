import { describe, it, expect, vi, beforeEach } from 'vitest';
import { api } from '../services/api';

describe('api service', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    localStorage.clear();
  });

  it('api.get gọi fetch với đúng URL và params', async () => {
    const mockData = { data: [], totalRecords: 0 };
    vi.spyOn(globalThis, 'fetch').mockResolvedValue({
      ok: true,
      status: 200,
      json: () => Promise.resolve(mockData),
    });

    const result = await api.get('/api/events', { status: 'success', page: 1 });

    expect(fetch).toHaveBeenCalledWith(
      expect.stringContaining('/api/events?'),
      expect.objectContaining({ headers: expect.any(Object) })
    );
    const calledUrl = fetch.mock.calls[0][0];
    expect(calledUrl).toContain('status=success');
    expect(calledUrl).toContain('page=1');
    expect(result).toEqual(mockData);
  });

  it('api.get bỏ qua param rỗng', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue({
      ok: true,
      status: 200,
      json: () => Promise.resolve({}),
    });

    await api.get('/api/events', { status: '', entity_type: 'table' });

    const calledUrl = fetch.mock.calls[0][0];
    expect(calledUrl).not.toContain('status=');
    expect(calledUrl).toContain('entity_type=table');
  });

  it('api.get gửi Authorization header nếu có token', async () => {
    localStorage.setItem('token', 'test-token');

    vi.spyOn(globalThis, 'fetch').mockResolvedValue({
      ok: true,
      status: 200,
      json: () => Promise.resolve({}),
    });

    await api.get('/api/events');

    const calledOptions = fetch.mock.calls[0][1];
    expect(calledOptions.headers['Authorization']).toBe('Bearer test-token');
  });

  it('api.post gửi body dạng JSON', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue({
      ok: true,
      status: 200,
      json: () => Promise.resolve({ token: 'abc' }),
    });

    const body = { username: 'admin', password: 'admin' };
    const result = await api.post('/api/login', body);

    const calledOptions = fetch.mock.calls[0][1];
    expect(calledOptions.method).toBe('POST');
    expect(calledOptions.headers['Content-Type']).toBe('application/json');
    expect(JSON.parse(calledOptions.body)).toEqual(body);
    expect(result.token).toBe('abc');
  });

  it('api throw error khi response không ok', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue({
      ok: false,
      status: 500,
      json: () => Promise.resolve({}),
    });

    await expect(api.get('/api/events')).rejects.toThrow('API Error: 500');
  });

  it('api redirect về /login khi 401', async () => {
    const locationSpy = vi.spyOn(window, 'location', 'get').mockReturnValue({
      ...window.location,
      href: '',
    });

    vi.spyOn(globalThis, 'fetch').mockResolvedValue({
      ok: false,
      status: 401,
      json: () => Promise.resolve({}),
    });

    await expect(api.get('/api/events')).rejects.toThrow('Unauthorized');
    locationSpy.mockRestore();
  });
});
