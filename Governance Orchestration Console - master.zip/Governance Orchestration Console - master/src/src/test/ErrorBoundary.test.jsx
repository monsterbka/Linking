import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import ErrorBoundary from '../components/ErrorBoundary';
import React from 'react';

const ThrowError = () => {
  throw new Error('Test explosion');
};

const GoodChild = () => <div>OK</div>;

describe('ErrorBoundary', () => {
  it('hiển thị children khi không có lỗi', () => {
    render(<ErrorBoundary><GoodChild /></ErrorBoundary>);
    expect(screen.getByText('OK')).toBeInTheDocument();
  });

  it('hiển thị fallback UI khi child throw error', () => {
    // Suppress console.error from ErrorBoundary
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {});

    render(<ErrorBoundary><ThrowError /></ErrorBoundary>);

    expect(screen.getByText('Đã xảy ra lỗi')).toBeInTheDocument();
    expect(screen.getByText('Thử lại')).toBeInTheDocument();

    spy.mockRestore();
  });
});
