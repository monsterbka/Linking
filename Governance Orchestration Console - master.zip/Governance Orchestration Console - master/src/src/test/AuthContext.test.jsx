import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { AuthProvider, useAuth } from '../contexts/AuthContext';
import React from 'react';

const TestConsumer = () => {
  const { user, isAuthenticated, login, logout, hasPermission } = useAuth();
  return (
    <div>
      <span data-testid="auth">{String(isAuthenticated)}</span>
      <span data-testid="user">{user?.name || 'none'}</span>
      <span data-testid="perm-events">{String(hasPermission('events'))}</span>
      <button onClick={() => login('tok', { name: 'Admin', permissions: ['events', 'metadata-reconcile'] })}>login</button>
      <button onClick={logout}>logout</button>
    </div>
  );
};

describe('AuthContext', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('mặc định chưa đăng nhập', () => {
    render(<AuthProvider><TestConsumer /></AuthProvider>);
    expect(screen.getByTestId('auth').textContent).toBe('false');
    expect(screen.getByTestId('user').textContent).toBe('none');
  });

  it('login lưu user vào state và localStorage', () => {
    render(<AuthProvider><TestConsumer /></AuthProvider>);

    fireEvent.click(screen.getByText('login'));

    expect(screen.getByTestId('auth').textContent).toBe('true');
    expect(screen.getByTestId('user').textContent).toBe('Admin');
    expect(localStorage.getItem('token')).toBe('tok');
  });

  it('logout xóa state và localStorage', () => {
    render(<AuthProvider><TestConsumer /></AuthProvider>);

    fireEvent.click(screen.getByText('login'));
    fireEvent.click(screen.getByText('logout'));

    expect(screen.getByTestId('auth').textContent).toBe('false');
    expect(localStorage.getItem('token')).toBeNull();
  });

  it('hasPermission trả true/false đúng', () => {
    render(<AuthProvider><TestConsumer /></AuthProvider>);

    fireEvent.click(screen.getByText('login'));

    expect(screen.getByTestId('perm-events').textContent).toBe('true');
  });

  it('khôi phục user từ localStorage', () => {
    localStorage.setItem('token', 'tok');
    localStorage.setItem('user', JSON.stringify({ name: 'Viewer', permissions: ['events'] }));

    render(<AuthProvider><TestConsumer /></AuthProvider>);

    expect(screen.getByTestId('auth').textContent).toBe('true');
    expect(screen.getByTestId('user').textContent).toBe('Viewer');
  });
});
