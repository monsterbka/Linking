import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import ErrorBoundary from './components/ErrorBoundary';
import Layout from './layouts/Layout';
import LoginPage from './pages/LoginPage';
import modules from './config/modules';

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return children;
};

const PermRoute = ({ perm, children }) => {
  const { hasPermission } = useAuth();
  if (!hasPermission(perm)) return <Navigate to="/" replace />;
  return children;
};

const DefaultRedirect = () => {
  const { user } = useAuth();
  const first = user?.permissions?.[0];
  const mod = modules.find(m => m.id === first);
  return <Navigate to={mod?.path || modules[0]?.path || '/'} replace />;
};

function App() {
  return (
    <ErrorBoundary>
      <Router>
        <AuthProvider>
          <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/*"
            element={
              <ProtectedRoute>
                <Layout>
                  <Routes>
                    {modules.map(mod => (
                      <Route
                        key={mod.id}
                        path={mod.path}
                        element={
                          <PermRoute perm={mod.id}>
                            <mod.component />
                          </PermRoute>
                        }
                      />
                    ))}
                    <Route path="*" element={<DefaultRedirect />} />
                  </Routes>
                </Layout>
              </ProtectedRoute>
            }
          />
        </Routes>
      </AuthProvider>
    </Router>
    </ErrorBoundary>
  );
}

export default App;
