import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';

const ENTITY_TYPES = ['created', 'updated', 'deleted'];
const EVENT_TYPES = ['table', 'tag'];
const SYNC_TYPES = ['webhook', 'reconcile'];
const STATUS_OPTIONS = ['running', 'success'];

const statusColor = {
  running: 'bg-blue-50 text-blue-600',
  success: 'bg-emerald-50 text-emerald-700',
};

const formatDateTime = (iso) => {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
};

const initialFilters = { entity_type: '', event_type: '', sync_type: '', status: '', sync_time_from: '', sync_time_to: '' };

const EventsPage = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState(initialFilters);
  const [appliedFilters, setAppliedFilters] = useState(initialFilters);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);

  const fetchEvents = useCallback(async (f = appliedFilters, p = page) => {
    setLoading(true);
    try {
      const params = { ...f, page: p, pageSize };
      if (params.sync_time_to) params.sync_time_to = params.sync_time_to + 'T23:59:59Z';
      const json = await api.get('/api/events', params);
      setEvents(json.data);
      setTotalPages(json.totalPages);
      setTotalRecords(json.totalRecords);
    } catch { setEvents([]); }
    setLoading(false);
  }, [appliedFilters, page, pageSize]);

  useEffect(() => { fetchEvents(); }, [fetchEvents]);

  const handleFilter = (e) => {
    e.preventDefault();
    setPage(1);
    setAppliedFilters({ ...filters });
  };

  const handleReset = () => {
    setFilters(initialFilters);
    setPage(1);
    setAppliedFilters(initialFilters);
  };

  const handleReload = () => fetchEvents(appliedFilters, page);

  const activeFilterCount = Object.values(appliedFilters).filter(Boolean).length;

  return (
    <div className="flex flex-col h-full gap-6">
      {/* Page Header */}
      <div className="flex-shrink-0">
        <h2 className="text-xl font-bold text-slate-900">Sự kiện đồng bộ</h2>
        <p className="text-sm text-slate-500 mt-0.5">Audit log các sự kiện đồng bộ giữa OpenMetadata và Apache Ranger</p>
      </div>

      {/* Filter Bar */}
      <form onSubmit={handleFilter} className="flex-shrink-0 bg-white rounded-xl border border-slate-200/60 p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-slate-400 text-[18px]">filter_list</span>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Bộ lọc</span>
            {activeFilterCount > 0 && (
              <span className="ml-1 px-1.5 py-0.5 text-[10px] font-bold bg-primary/10 text-primary rounded-full">{activeFilterCount}</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={handleReset} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-700 transition-colors">
              <span className="material-symbols-outlined text-[16px]">close</span> Xóa lọc
            </button>
            <button type="submit" className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-primary text-on-primary text-xs font-bold uppercase tracking-wider rounded-lg hover:bg-primary-dim transition-colors">
              <span className="material-symbols-outlined text-[16px]">search</span> Lọc
            </button>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          <Select label="Sync Type" value={filters.sync_type} options={SYNC_TYPES} onChange={v => setFilters(f => ({ ...f, sync_type: v }))} />
          <Select label="Entity Type" value={filters.entity_type} options={ENTITY_TYPES} onChange={v => setFilters(f => ({ ...f, entity_type: v }))} />
          <Select label="Event Type" value={filters.event_type} options={EVENT_TYPES} onChange={v => setFilters(f => ({ ...f, event_type: v }))} />
          <Select label="Status" value={filters.status} options={STATUS_OPTIONS} onChange={v => setFilters(f => ({ ...f, status: v }))} />
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Sync từ</label>
            <input type="date" value={filters.sync_time_from} onChange={e => setFilters(f => ({ ...f, sync_time_from: e.target.value }))}
              className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-primary focus:border-primary" />
          </div>
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Sync đến</label>
            <input type="date" value={filters.sync_time_to} min={filters.sync_time_from || undefined} onChange={e => setFilters(f => ({ ...f, sync_time_to: e.target.value }))}
              className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-primary focus:border-primary" />
          </div>
        </div>
      </form>

      {/* Table */}
      <div className="flex-1 min-h-0 bg-white rounded-xl border border-slate-200/60 flex flex-col overflow-hidden">
        <div className="flex-1 min-h-0 overflow-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              <tr className="bg-slate-50 border-b border-slate-200/60">
                <Th>Event ID</Th>
                <Th>Entity Type</Th>
                <Th>Event Type</Th>
                <Th>Sync Type</Th>
                <Th>Event Time</Th>
                <Th>Sync Time</Th>
                <Th>Status</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr><td colSpan={7} className="text-center py-12 text-slate-400"><span className="material-symbols-outlined animate-spin text-2xl">progress_activity</span></td></tr>
              ) : events.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-12 text-slate-400">
                  <span className="material-symbols-outlined text-3xl mb-1 block">inbox</span>
                  <span className="text-xs">Không có dữ liệu</span>
                </td></tr>
              ) : events.map(ev => (
                <tr key={ev.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-4 py-3 font-mono text-xs text-primary font-medium">{ev.event_id}</td>
                  <td className="px-4 py-3 text-slate-700">{ev.entity_type}</td>
                  <td className="px-4 py-3 text-slate-700">{ev.event_type}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-full ${ev.sync_type === 'webhook' ? 'bg-blue-50 text-blue-600' : 'bg-violet-50 text-violet-600'}`}>
                      {ev.sync_type}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs">{formatDateTime(ev.event_time)}</td>
                  <td className="px-4 py-3 text-slate-500 text-xs">{formatDateTime(ev.sync_time)}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-full ${statusColor[ev.status] || 'bg-slate-100 text-slate-500'}`}>
                      {ev.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Footer */}
        {!loading && events.length > 0 && (
          <div className="px-4 py-3 bg-slate-50/50 border-t border-slate-200/60 flex items-center justify-between">
            <span className="text-xs text-slate-400">Hiển thị {events.length} / {totalRecords} bản ghi</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setPage(1)} disabled={page <= 1} className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <span className="material-symbols-outlined text-[18px] text-slate-500">first_page</span>
              </button>
              <button onClick={() => setPage(p => p - 1)} disabled={page <= 1} className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <span className="material-symbols-outlined text-[18px] text-slate-500">chevron_left</span>
              </button>
              <span className="px-3 py-1 text-xs font-medium text-slate-600">Trang {page} / {totalPages}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={page >= totalPages} className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <span className="material-symbols-outlined text-[18px] text-slate-500">chevron_right</span>
              </button>
              <button onClick={() => setPage(totalPages)} disabled={page >= totalPages} className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <span className="material-symbols-outlined text-[18px] text-slate-500">last_page</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ── Sub-components ──────────────────────────
const Th = ({ children }) => (
  <th className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider whitespace-nowrap">{children}</th>
);

const Select = ({ label, value, options, onChange }) => (
  <div>
    <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">{label}</label>
    <select value={value} onChange={e => onChange(e.target.value)}
      className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-primary focus:border-primary appearance-none">
      <option value="">Tất cả</option>
      {options.map(o => <option key={o} value={o}>{o}</option>)}
    </select>
  </div>
);

export default EventsPage;
