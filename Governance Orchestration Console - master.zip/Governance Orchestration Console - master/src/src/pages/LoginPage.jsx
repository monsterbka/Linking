import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../services/api';

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const data = await api.post('/api/login', { username, password });
      login(data.token, data.user);
      navigate('/');
    } catch (err) {
      setError('Sai tài khoản hoặc mật khẩu');
    }
  };

  return (
    <div className="bg-surface text-on-surface min-h-screen flex items-center justify-center p-6">
      {/* Background Decoration */}
      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-5%] w-[40%] h-[40%] rounded-full bg-primary/5 blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-5%] w-[30%] h-[30%] rounded-full bg-secondary/5 blur-[100px]"></div>
      </div>

      <main className="w-full max-w-[440px] flex flex-col items-center">
        {/* Logo */}
        <div className="mb-10 flex flex-col items-center">
          <div className="w-14 h-14 bg-linear-to-br from-primary to-primary-dim rounded-lg flex items-center justify-center mb-6 shadow-sm">
            <span className="material-symbols-outlined text-on-primary text-3xl">account_tree</span>
          </div>
          <h1 className="text-on-surface font-extrabold text-xl tracking-tighter uppercase mb-1">
            Governance Orchestration Console
          </h1>
          <p className="text-on-surface-variant text-xs tracking-widest uppercase">
            Secure Administrative Portal
          </p>
        </div>

        {/* Card */}
        <section className="w-full bg-surface-container-lowest/85 backdrop-blur-sm rounded-xl p-10 shadow-[0_20px_40px_rgba(43,52,56,0.05)] border border-surface-variant/30">
          <form className="space-y-6" onSubmit={handleSubmit}>
            {/* Username */}
            <div className="space-y-2">
              <label className="block text-on-surface-variant text-[11px] font-semibold tracking-wider uppercase ml-1" htmlFor="username">
                Corporate Identifier
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-outline">
                  <span className="material-symbols-outlined text-[20px]">person</span>
                </div>
                <input
                  className="w-full h-12 pl-12 pr-4 bg-surface-container-highest border-none rounded-lg text-sm focus:ring-1 focus:ring-primary focus:bg-surface-container-lowest transition-all placeholder:text-outline-variant"
                  id="username"
                  placeholder="username@org.local"
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-2">
              <div className="flex justify-between items-center px-1">
                <label className="block text-on-surface-variant text-[11px] font-semibold tracking-wider uppercase" htmlFor="password">
                  Security Credentials
                </label>
                <a className="text-primary text-[11px] font-bold tracking-wider uppercase hover:text-primary-dim transition-colors cursor-pointer">
                  Forgot Password?
                </a>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-outline">
                  <span className="material-symbols-outlined text-[20px]">lock</span>
                </div>
                <input
                  className="w-full h-12 pl-12 pr-12 bg-surface-container-highest border-none rounded-lg text-sm focus:ring-1 focus:ring-primary focus:bg-surface-container-lowest transition-all placeholder:text-outline-variant"
                  id="password"
                  placeholder="••••••••••••"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                />
                <button
                  className="absolute inset-y-0 right-4 flex items-center text-outline hover:text-on-surface transition-colors"
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  <span className="material-symbols-outlined text-[20px]">
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </span>
                </button>
              </div>
            </div>

            {/* Remember */}
            <div className="flex items-center px-1">
              <label className="flex items-center gap-3 cursor-pointer group">
                <input className="w-4 h-4 rounded border-2 border-outline-variant accent-primary" type="checkbox" />
                <span className="text-on-surface-variant text-[11px] font-medium tracking-tight group-hover:text-on-surface transition-colors">
                  Remember this workstation for 30 days
                </span>
              </label>
            </div>

            {/* Error */}
            {error && (
              <div className="text-error text-sm text-center font-medium">{error}</div>
            )}

            {/* Submit */}
            <div className="pt-2">
              <button
                className="w-full h-12 bg-linear-to-br from-primary to-primary-dim text-on-primary text-sm font-bold tracking-widest uppercase rounded-lg shadow-md hover:shadow-lg active:scale-[0.98] transition-all flex items-center justify-center gap-2"
                type="submit"
              >
                Sign In
                <span className="material-symbols-outlined text-[18px]">login</span>
              </button>
            </div>
          </form>

          {/* Footer Meta */}
          <div className="mt-8 pt-8 border-t border-surface-variant/50 flex flex-col items-center gap-4">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-1 text-[10px] text-on-surface-variant font-medium tracking-tighter">
                <span className="material-symbols-outlined text-[14px]">verified_user</span>
                AES-256 Encrypted
              </div>
              <div className="flex items-center gap-1 text-[10px] text-on-surface-variant font-medium tracking-tighter">
                <span className="material-symbols-outlined text-[14px]">hub</span>
                Single Sign-On Enabled
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="mt-12 text-center space-y-2">
          <p className="text-[10px] text-outline uppercase font-semibold tracking-[0.2em]">
            Unauthorized access is strictly prohibited
          </p>
          <nav className="flex justify-center gap-4">
            <a className="text-[10px] text-on-surface-variant hover:text-primary transition-colors cursor-pointer">Privacy Protocol</a>
            <span className="text-outline-variant text-[10px]">•</span>
            <a className="text-[10px] text-on-surface-variant hover:text-primary transition-colors cursor-pointer">System Status</a>
            <span className="text-outline-variant text-[10px]">•</span>
            <a className="text-[10px] text-on-surface-variant hover:text-primary transition-colors cursor-pointer">Support Registry</a>
          </nav>
        </footer>
      </main>

      {/* Bottom Line */}
      <div className="fixed bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/20 to-transparent"></div>
    </div>
  );
};

export default LoginPage;
