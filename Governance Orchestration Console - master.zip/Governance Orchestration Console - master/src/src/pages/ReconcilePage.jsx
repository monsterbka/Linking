import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';

const STATUS_OPTIONS = ['success', 'failed', 'running'];
const MATCHED_OPTIONS = [
  { value: 'true', label: 'Khớp' },
  { value: 'false', label: 'Không khớp' },
];

const statusColor = {
  success: 'bg-emerald-50 text-emerald-700',
  failed: 'bg-red-50 text-red-700',
  running: 'bg-blue-50 text-blue-600',
};

const formatDateTime = (iso) => {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
};

const formatDuration = (sec) => {
  if (sec == null) return '—';
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
};

const initialFilters = { status: '', is_matched: '', job_time_from: '', job_time_to: '' };

const ReconcilePage = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState(initialFilters);
  const [appliedFilters, setAppliedFilters] = useState(initialFilters);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);
  const [metadataModal, setMetadataModal] = useState(null);
  const [metadataLoading, setMetadataLoading] = useState(false);
  const [forcing, setForcing] = useState(false);
  const [forceMsg, setForceMsg] = useState('');
  const [showConfirm, setShowConfirm] = useState(false);

  const fetchData = useCallback(async (f = appliedFilters, p = page) => {
    setLoading(true);
    try {
      const params = { ...f, page: p, pageSize };
      if (params.job_time_to) params.job_time_to = params.job_time_to + 'T23:59:59Z';
      const json = await api.get('/api/metadata-reconcile', params);
      setData(json.data);
      setTotalPages(json.totalPages);
      setTotalRecords(json.totalRecords);
    } catch { setData([]); }
    setLoading(false);
  }, [appliedFilters, page, pageSize]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleFilter = (e) => { e.preventDefault(); setPage(1); setAppliedFilters({ ...filters }); };
  const handleReset = () => { setFilters(initialFilters); setPage(1); setAppliedFilters(initialFilters); };
  const handleReload = () => fetchData(appliedFilters, page);

  const handleForce = () => setShowConfirm(true);

  const handleConfirmForce = async () => {
    setShowConfirm(false);
    setForcing(true);
    setForceMsg('');
    try {
      const result = await api.post('/api/metadata-reconcile/force');
      setForceMsg(result.message || 'Đã gửi yêu cầu đối soát');
      await fetchData(appliedFilters, page);
    } catch { setForceMsg('Lỗi khi đối soát'); }
    setForcing(false);
    setTimeout(() => setForceMsg(''), 4000);
  };

  const activeFilterCount = Object.values(appliedFilters).filter(Boolean).length;

  const handleViewMetadata = async (id) => {
    setMetadataLoading(true);
    try {
      const result = await api.get(`/api/metadata-reconcile/${id}/metadata`);
      setMetadataModal(result);
    } catch { setMetadataModal({ id, metadata: [] }); }
    setMetadataLoading(false);
  };

  return (
    <div className="flex flex-col h-full gap-6">
      {/* Page Header */}
      <div className="flex-shrink-0 flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Đối soát dữ liệu</h2>
          <p className="text-sm text-slate-500 mt-0.5">Danh sách các job đối soát giữa OpenMetadata và Apache Ranger</p>
        </div>
        <button
          onClick={handleForce}
          disabled={forcing}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary text-on-primary text-sm font-medium rounded-lg hover:bg-primary-dim active:scale-95 transition-all disabled:opacity-50"
        >
          <span className={`material-symbols-outlined text-[18px] ${forcing ? 'animate-spin' : ''}`}>{forcing ? 'progress_activity' : 'play_arrow'}</span>
          {forcing ? 'Đang xử lý...' : 'Đối soát'}
        </button>
      </div>

      {/* Force message */}
      {forceMsg && (
        <div className="px-4 py-3 bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm rounded-lg flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px]">check_circle</span>
          {forceMsg}
        </div>
      )}

      {/* Confirm Dialog */}
      {showConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setShowConfirm(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 overflow-hidden" onClick={e => e.stopPropagation()}>
            <div className="flex items-start gap-4 p-6">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center mt-1">
                <span className="material-symbols-outlined text-amber-500 text-[28px]">warning</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-900 mb-1">Xác nhận đối soát</h3>
                <p className="text-sm text-slate-500">Bạn có chắc chắn muốn thực hiện đối soát?</p>
              </div>
            </div>
            <div className="flex border-t border-slate-100">
              <button onClick={() => setShowConfirm(false)} className="flex-1 py-3 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors">Hủy</button>
              <button onClick={handleConfirmForce} className="flex-1 py-3 text-sm font-semibold text-primary hover:bg-primary/5 border-l border-slate-100 transition-colors">Đồng ý</button>
            </div>
          </div>
        </div>
      )}

      {/* Filter Bar */}
      <form onSubmit={handleFilter} className="flex-shrink-0 bg-white rounded-xl border border-slate-200/60 p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-slate-400 text-[18px]">filter_list</span>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Bộ lọc</span>
            {activeFilterCount > 0 && (
              <span className="ml-1 px-1.5 py-0.5 text-[10px] font-bold bg-primary/10 text-primary rounded-full">{activeFilterCount}</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button type="button" onClick={handleReset} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-700 transition-colors">
              <span className="material-symbols-outlined text-[16px]">close</span> Xóa lọc
            </button>
            <button type="submit" className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-primary text-on-primary text-xs font-bold uppercase tracking-wider rounded-lg hover:bg-primary-dim transition-colors">
              <span className="material-symbols-outlined text-[16px]">search</span> Lọc
            </button>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <FilterSelect label="Status" value={filters.status} options={STATUS_OPTIONS.map(s => ({ value: s, label: s }))} onChange={v => setFilters(f => ({ ...f, status: v }))} />
          <FilterSelect label="Kết quả khớp" value={filters.is_matched} options={MATCHED_OPTIONS} onChange={v => setFilters(f => ({ ...f, is_matched: v }))} />
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Job từ ngày</label>
            <input type="date" value={filters.job_time_from} onChange={e => setFilters(f => ({ ...f, job_time_from: e.target.value }))}
              className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-primary focus:border-primary" />
          </div>
          <div>
            <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Job đến ngày</label>
            <input type="date" value={filters.job_time_to} min={filters.job_time_from || undefined} onChange={e => setFilters(f => ({ ...f, job_time_to: e.target.value }))}
              className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-primary focus:border-primary" />
          </div>
        </div>
      </form>

      {/* Table */}
      <div className="flex-1 min-h-0 bg-white rounded-xl border border-slate-200/60 flex flex-col overflow-hidden">
        <div className="flex-1 min-h-0 overflow-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              <tr className="bg-slate-50 border-b border-slate-200/60">
                <Th>Thời gian</Th>
                <Th>Thời lượng</Th>
                <Th>Loại</Th>
                <Th>Status</Th>
                <Th>Khớp</Th>
                <Th>Sync Mismatch (s)</Th>
                <Th>Sync mismatch</Th>
                <Th>Metadata</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr><td colSpan={8} className="text-center py-12 text-slate-400"><span className="material-symbols-outlined animate-spin text-2xl">progress_activity</span></td></tr>
              ) : data.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-slate-400">
                  <span className="material-symbols-outlined text-3xl mb-1 block">inbox</span>
                  <span className="text-xs">Không có dữ liệu</span>
                </td></tr>
              ) : data.map(row => (
                <tr key={row.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-4 py-3 text-slate-500 text-xs">{formatDateTime(row.job_time)}</td>
                  <td className="px-4 py-3 text-slate-700">{formatDuration(row.duration)}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-full ${row.job_type === 'schedule' ? 'bg-slate-100 text-slate-600' : 'bg-violet-50 text-violet-600'}`}>
                      {row.job_type}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-full ${statusColor[row.status] || 'bg-slate-100 text-slate-500'}`}>
                      {row.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {row.is_matched
                      ? <span className="inline-flex items-center gap-0.5 text-emerald-600 text-xs font-medium"><span className="material-symbols-outlined text-[16px]">check_circle</span> Khớp</span>
                      : <span className="inline-flex items-center gap-0.5 text-red-500 text-xs font-medium"><span className="material-symbols-outlined text-[16px]">cancel</span> Lệch</span>
                    }
                  </td>
                  <td className="px-4 py-3 text-slate-500 font-mono">{row.sync_mismatch_duration > 0 ? `${row.sync_mismatch_duration}s` : '—'}</td>
                  <td className="px-4 py-3">
                    {row.sync_mismatch_status && (
                      <span className={`inline-flex items-center px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider rounded-full ${statusColor[row.sync_mismatch_status] || 'bg-slate-100 text-slate-500'}`}>
                        {row.sync_mismatch_status}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <button onClick={() => handleViewMetadata(row.id)} className="text-xs font-medium text-primary hover:text-primary-dim transition-colors">
                      Xem
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!loading && data.length > 0 && (
          <div className="px-4 py-3 bg-slate-50/50 border-t border-slate-200/60 flex items-center justify-between">
            <span className="text-xs text-slate-400">Hiển thị {data.length} / {totalRecords} bản ghi</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setPage(1)} disabled={page <= 1} className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <span className="material-symbols-outlined text-[18px] text-slate-500">first_page</span>
              </button>
              <button onClick={() => setPage(p => p - 1)} disabled={page <= 1} className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <span className="material-symbols-outlined text-[18px] text-slate-500">chevron_left</span>
              </button>
              <span className="px-3 py-1 text-xs font-medium text-slate-600">Trang {page} / {totalPages}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={page >= totalPages} className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <span className="material-symbols-outlined text-[18px] text-slate-500">chevron_right</span>
              </button>
              <button onClick={() => setPage(totalPages)} disabled={page >= totalPages} className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <span className="material-symbols-outlined text-[18px] text-slate-500">last_page</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Metadata Modal */}
      {metadataModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={() => setMetadataModal(null)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full mx-4 max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary">data_object</span>
                <h3 className="text-base font-semibold text-slate-900">Metadata — Dữ liệu lệch</h3>
              </div>
              <button onClick={() => setMetadataModal(null)} className="p-1 rounded-lg hover:bg-slate-100 transition-colors">
                <span className="material-symbols-outlined text-slate-400">close</span>
              </button>
            </div>
            <div className="flex-1 overflow-auto p-6">
              {metadataModal.metadata && metadataModal.metadata.length > 0 ? (
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200/60">
                      <th className="px-3 py-2 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider">Type</th>
                      <th className="px-3 py-2 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider">Table</th>
                      <th className="px-3 py-2 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider">Columns</th>
                      <th className="px-3 py-2 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider">Tag</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {metadataModal.metadata.map((m, i) => (
                      <tr key={i} className="hover:bg-slate-50/50">
                        <td className="px-3 py-2 text-xs font-medium text-slate-700">{m.type}</td>
                        <td className="px-3 py-2 text-xs font-mono text-slate-600">{m.table}</td>
                        <td className="px-3 py-2 text-xs font-mono text-slate-600">{m.columns}</td>
                        <td className="px-3 py-2"><span className="inline-flex px-2 py-0.5 text-[10px] font-bold rounded-full bg-amber-50 text-amber-700">{m.tag}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="text-center py-8 text-slate-400">
                  <span className="material-symbols-outlined text-3xl mb-1 block">check_circle</span>
                  <span className="text-sm">Không có dữ liệu lệch</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ── Sub-components ──────────────────────────
const Th = ({ children }) => (
  <th className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider whitespace-nowrap">{children}</th>
);

const FilterSelect = ({ label, value, options, onChange }) => (
  <div>
    <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5">{label}</label>
    <select value={value} onChange={e => onChange(e.target.value)}
      className="w-full h-9 px-3 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-1 focus:ring-primary focus:border-primary appearance-none">
      <option value="">Tất cả</option>
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  </div>
);

export default ReconcilePage;
