import React from 'react';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('[ErrorBoundary]', error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-surface p-6">
          <div className="max-w-md w-full bg-white rounded-xl border border-slate-200 p-8 text-center">
            <span className="material-symbols-outlined text-5xl text-error mb-4 block">error</span>
            <h2 className="text-lg font-bold text-slate-900 mb-2">Đã xảy ra lỗi</h2>
            <p className="text-sm text-slate-500 mb-6">
              Ứng dụng gặp sự cố không mong muốn. Vui lòng thử lại.
            </p>
            <button
              onClick={this.handleReset}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-on-primary text-sm font-medium rounded-lg hover:bg-primary-dim transition-colors"
            >
              <span className="material-symbols-outlined text-[18px]">refresh</span>
              Thử lại
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
