import { test, expect } from '@playwright/test';

// Helper: login rồi navigate đến trang cần test
async function loginAsAdmin(page) {
  await page.goto('/login');
  await page.evaluate(() => localStorage.clear());
  await page.goto('/login');
  await page.fill('#username', 'admin');
  await page.fill('#password', 'admin');
  await page.click('button[type="submit"]');
  await page.waitForURL('**/events');
}

test.describe('Events Page', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
    await page.goto('/events');
  });

  test('hiển thị tiêu đề và bảng dữ liệu', async ({ page }) => {
    await expect(page.locator('h2')).toContainText('Sự kiện đồng bộ');
    // Bảng có header columns
    await expect(page.locator('th:text("Event ID")')).toBeVisible();
    await expect(page.locator('th:text("Entity Type")')).toBeVisible();
    await expect(page.locator('th:text("Status")')).toBeVisible();
    // Có dữ liệu trong bảng
    await expect(page.locator('tbody tr').first()).toBeVisible();
  });

  test('bộ lọc hiển thị đầy đủ', async ({ page }) => {
    await expect(page.locator('text=Bộ lọc')).toBeVisible();
    // 4 select + 2 date inputs
    await expect(page.locator('select')).toHaveCount(4);
    await expect(page.locator('input[type="date"]')).toHaveCount(2);
    await expect(page.locator('button[type="submit"]')).toBeVisible();
    await expect(page.getByRole('button', { name: /xóa lọc/i })).toBeVisible();
  });

  test('lọc theo status', async ({ page }) => {
    // Chọn filter status = failed
    const selects = page.locator('select');
    await selects.nth(3).selectOption('running'); // Status là select thứ 4
    await page.locator('button[type="submit"]').click();

    // Chờ load xong
    await page.waitForTimeout(500);

    // Tất cả rows hiển thị phải có status = running
    const statusCells = page.locator('tbody tr td:nth-child(7) span');
    const count = await statusCells.count();
    if (count > 0) {
      for (let i = 0; i < count; i++) {
        await expect(statusCells.nth(i)).toContainText('running');
      }
    }
  });

  test('xóa lọc reset bộ lọc', async ({ page }) => {
    // Chọn filter
    const selects = page.locator('select');
    await selects.nth(0).selectOption('webhook');
    await page.locator('button[type="submit"]').click();
    await page.waitForTimeout(300);

    // Xóa lọc
    await page.getByRole('button', { name: /xóa lọc/i }).click();
    await page.waitForTimeout(300);

    // Select phải reset về "Tất cả"
    await expect(selects.nth(0)).toHaveValue('');
  });

  test('phân trang hoạt động', async ({ page }) => {
    await expect(page.getByText(/Trang 1 \//)).toBeVisible();
  });

  test('ràng buộc ngày: đến ngày >= từ ngày', async ({ page }) => {
    const dateFrom = page.locator('input[type="date"]').nth(0);
    const dateTo = page.locator('input[type="date"]').nth(1);

    await dateFrom.fill('2026-03-01');
    // DateTo phải có min = 2026-03-01
    await expect(dateTo).toHaveAttribute('min', '2026-03-01');
  });
});
