import { test, expect } from '@playwright/test';

test.describe('Login Page', () => {
  test.beforeEach(async ({ page }) => {
    // Clear localStorage trước mỗi test
    await page.goto('/login');
    await page.evaluate(() => localStorage.clear());
    await page.goto('/login');
  });

  test('hiển thị form đăng nhập', async ({ page }) => {
    await expect(page.locator('h1')).toContainText('Governance Orchestration Console');
    await expect(page.locator('#username')).toBeVisible();
    await expect(page.locator('#password')).toBeVisible();
    await expect(page.getByRole('button', { name: /sign in/i })).toBeVisible();
  });

  test('đăng nhập thành công với admin', async ({ page }) => {
    await page.fill('#username', 'admin');
    await page.fill('#password', 'admin');
    await page.click('button[type="submit"]');

    // Chuyển hướng đến trang chính
    await expect(page).not.toHaveURL(/login/);
    // Sidebar hiển thị
    await expect(page.getByRole('link', { name: 'event Sự kiện', exact: true })).toBeVisible();
  });

  test('đăng nhập thất bại hiển thị lỗi', async ({ page }) => {
    await page.fill('#username', 'wrong');
    await page.fill('#password', 'wrong');
    await page.click('button[type="submit"]');

    await expect(page.locator('text=Sai tài khoản hoặc mật khẩu')).toBeVisible();
    await expect(page).toHaveURL(/login/);
  });

  test('toggle hiển thị mật khẩu', async ({ page }) => {
    await page.fill('#password', 'secret');

    const passwordInput = page.locator('#password');
    await expect(passwordInput).toHaveAttribute('type', 'password');

    // Click toggle button
    await page.locator('button:has(span:text("visibility"))').click();
    await expect(passwordInput).toHaveAttribute('type', 'text');

    // Click lần nữa để ẩn
    await page.locator('button:has(span:text("visibility_off"))').click();
    await expect(passwordInput).toHaveAttribute('type', 'password');
  });

  test('chuyển hướng về login khi chưa đăng nhập', async ({ page }) => {
    await page.goto('/events');
    await expect(page).toHaveURL(/login/);
  });
});
