import { test, expect } from '@playwright/test';

async function loginAsAdmin(page) {
  await page.goto('/login');
  await page.evaluate(() => localStorage.clear());
  await page.goto('/login');
  await page.fill('#username', 'admin');
  await page.fill('#password', 'admin');
  await page.click('button[type="submit"]');
  await page.waitForURL('**/events');
}

test.describe('Events Reconcile Page', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
    await page.goto('/events-reconcile');
  });

  test('hiển thị tiêu đề và bảng dữ liệu', async ({ page }) => {
    await expect(page.locator('h2')).toContainText('Đối soát sự kiện');
    const headers = page.locator('thead th');
    await expect(headers.filter({ hasText: 'Thời gian' })).toBeVisible();
    await expect(headers.filter({ hasText: 'Thời lượng' })).toBeVisible();
    await expect(headers.filter({ hasText: 'Khớp' })).toBeVisible();
    await expect(headers.filter({ hasText: 'Metadata' })).toBeVisible();
    await expect(page.locator('tbody tr').first()).toBeVisible();
  });

  test('nút Đối soát hiển thị', async ({ page }) => {
    const forceBtn = page.getByRole('button', { name: /đối soát/i });
    await expect(forceBtn).toBeVisible();
  });

  test('Đối soát hiển thị confirm dialog và thực hiện', async ({ page }) => {
    await page.getByRole('button', { name: /đối soát/i }).click();
    await expect(page.getByText('Xác nhận đối soát')).toBeVisible();
    await expect(page.getByText('Bạn có chắc chắn muốn thực hiện đối soát?')).toBeVisible();
    await page.getByRole('button', { name: /đồng ý/i }).click();
    await expect(page.getByText('Đã gửi yêu cầu force đối soát thành công')).toBeVisible();
  });

  test('Đối soát hủy khi không confirm', async ({ page }) => {
    await page.getByRole('button', { name: /đối soát/i }).click();
    await expect(page.getByText('Xác nhận đối soát')).toBeVisible();
    await page.getByRole('button', { name: /hủy/i }).click();
    await expect(page.getByText('Xác nhận đối soát')).not.toBeVisible();
    await expect(page.getByText(/đối soát.*thành công/i)).not.toBeVisible();
  });

  test('bộ lọc hoạt động', async ({ page }) => {
    await expect(page.getByText('Bộ lọc')).toBeVisible();

    const selects = page.locator('select');
    await expect(selects).toHaveCount(2);

    // Lọc theo status = running
    await selects.nth(0).selectOption('running');
    await page.locator('button[type="submit"]').click();
    await page.waitForTimeout(500);

    const rows = page.locator('tbody tr');
    const count = await rows.count();
    if (count > 0) {
      for (let i = 0; i < count; i++) {
        const statusCell = rows.nth(i).locator('td:nth-child(4) span');
        await expect(statusCell).toContainText('running');
      }
    }
  });

  test('click Xem metadata hiển thị modal', async ({ page }) => {
    const viewBtn = page.locator('tbody tr').first().getByText('Xem');
    await viewBtn.click();

    // Modal hiển thị
    await expect(page.getByText('Metadata Log')).toBeVisible();

    // Đóng modal
    await page.locator('.fixed button:has(span:text("close"))').click();
    await expect(page.getByText('Metadata Log')).not.toBeVisible();
  });

  test('metadata modal hiển thị log khi có dữ liệu', async ({ page }) => {
    // Row thứ 3 (index 2) có metadata log (is_matched: false)
    const viewBtn = page.locator('tbody tr').nth(2).getByText('Xem');
    await viewBtn.click();

    await expect(page.getByText('Metadata Log')).toBeVisible();
    // Phải có pre element chứa log text
    await expect(page.locator('.fixed pre')).toBeVisible();
    await expect(page.locator('.fixed pre')).toContainText('ERROR');

    // Đóng modal bằng click overlay
    await page.locator('.fixed.inset-0').click({ position: { x: 10, y: 10 } });
    await expect(page.getByText('Metadata Log')).not.toBeVisible();
  });

  test('phân trang hiển thị', async ({ page }) => {
    await expect(page.getByText(/Trang 1/)).toBeVisible();
  });
});
