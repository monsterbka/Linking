import { test, expect } from '@playwright/test';

async function loginAsAdmin(page) {
  await page.goto('/login');
  await page.evaluate(() => localStorage.clear());
  await page.goto('/login');
  await page.fill('#username', 'admin');
  await page.fill('#password', 'admin');
  await page.click('button[type="submit"]');
  await page.waitForURL('**/events');
}

test.describe('Reconcile Page', () => {
  test.beforeEach(async ({ page }) => {
    await loginAsAdmin(page);
    await page.goto('/metadata-reconcile');
  });

  test('hiển thị tiêu đề và bảng dữ liệu', async ({ page }) => {
    await expect(page.locator('h2')).toContainText('Đối soát dữ liệu');
    const headers = page.locator('thead th');
    await expect(headers.filter({ hasText: 'Thời gian' })).toBeVisible();
    await expect(headers.filter({ hasText: 'Khớp' })).toBeVisible();
    await expect(headers.filter({ hasText: 'Sync Mismatch (s)' })).toBeVisible();
    await expect(headers.filter({ hasText: /^Sync mismatch$/ })).toBeVisible();
    await expect(headers.filter({ hasText: 'Metadata' })).toBeVisible();
    await expect(page.locator('tbody tr').first()).toBeVisible();
  });

  test('bộ lọc hiển thị đầy đủ', async ({ page }) => {
    await expect(page.locator('text=Bộ lọc')).toBeVisible();
    await expect(page.locator('select')).toHaveCount(2);
    await expect(page.locator('input[type="date"]')).toHaveCount(2);
  });

  test('lọc theo kết quả khớp', async ({ page }) => {
    const selects = page.locator('select');
    await selects.nth(1).selectOption('true');
    await page.locator('button[type="submit"]').click();
    await page.waitForTimeout(500);

    const matchCells = page.locator('tbody tr td:nth-child(5)');
    const count = await matchCells.count();
    if (count > 0) {
      for (let i = 0; i < count; i++) {
        await expect(matchCells.nth(i)).toContainText('Khớp');
      }
    }
  });

  test('hiển thị thời lượng job', async ({ page }) => {
    const durationCell = page.locator('tbody tr td:nth-child(2)').first();
    const text = await durationCell.textContent();
    expect(text).toMatch(/\d+[ms]/);
  });

  test('click Xem metadata hiển thị modal', async ({ page }) => {
    const viewBtn = page.locator('tbody tr').first().getByText('Xem');
    await viewBtn.click();
    await expect(page.getByText('Metadata — Dữ liệu lệch')).toBeVisible();

    // Đóng modal
    await page.locator('.fixed button:has(span:text("close"))').click();
    await expect(page.getByText('Metadata — Dữ liệu lệch')).not.toBeVisible();
  });

  test('metadata modal hiển thị bảng dữ liệu lệch', async ({ page }) => {
    // Row 3 (index 2) has metadata with mismatched items
    const viewBtn = page.locator('tbody tr').nth(2).getByText('Xem');
    await viewBtn.click();

    await expect(page.getByText('Metadata — Dữ liệu lệch')).toBeVisible();
    await expect(page.locator('.fixed table')).toBeVisible();
    await expect(page.locator('.fixed table tbody tr').first()).toBeVisible();

    await page.locator('.fixed.inset-0').click({ position: { x: 10, y: 10 } });
    await expect(page.getByText('Metadata — Dữ liệu lệch')).not.toBeVisible();
  });

  test('phân trang hoạt động', async ({ page }) => {
    await expect(page.locator('text=Trang 1')).toBeVisible();
    await expect(page.locator('text=/Hiển thị \\d+/')).toBeVisible();
  });
});
