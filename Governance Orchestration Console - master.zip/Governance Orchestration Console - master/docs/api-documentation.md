# Tài liệu API – Governance Orchestration Console

> Phiên bản: 2.0 | Cập nhật: 02/04/2026
> Base URL: `/api`

---

## Mục lục

1. [Xác thực (Login)](#1-xác-thực-login)
2. [Sự kiện đồng bộ (Events)](#2-sự-kiện-đồng-bộ-events)
3. [Đối soát dữ liệu (Metadata Reconcile)](#3-đối-soát-dữ-liệu-metadata-reconcile)
4. [Đối soát sự kiện (Events Reconcile)](#4-đối-soát-sự-kiện-events-reconcile)
5. [Cấu trúc phân trang chung](#5-cấu-trúc-phân-trang-chung)
6. [Mã trạng thái HTTP](#6-mã-trạng-thái-http)

---

## 1. Xác thực (Login)

### POST `/api/login`

Đăng nhập hệ thống và nhận token xác thực.

**Request Body:**

| Trường     | Kiểu   | Bắt buộc | Mô tả          |
|------------|--------|----------|-----------------|
| `username` | string | ✅       | Tên đăng nhập   |
| `password` | string | ✅       | Mật khẩu        |

**Ví dụ request:**
```json
{
  "username": "admin",
  "password": "123456"
}
```

**Response thành công (200):**

| Trường               | Kiểu     | Mô tả                                       |
|----------------------|----------|----------------------------------------------|
| `token`              | string   | JWT token cho các request tiếp theo          |
| `user.name`          | string   | Tên hiển thị của người dùng                  |
| `user.role`          | string   | Vai trò: `admin`, `viewer`, `operator`       |
| `user.permissions`   | string[] | Danh sách module được phép truy cập          |

**Ví dụ response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "name": "Admin",
    "role": "admin",
    "permissions": ["events", "events-reconcile", "metadata-reconcile"]
  }
}
```

**Danh sách tài khoản mock:**

| Username   | Role       | Permissions                                       |
|------------|------------|---------------------------------------------------|
| `admin`    | admin      | events, events-reconcile, metadata-reconcile       |
| `viewer`   | viewer     | events                                             |
| `operator` | operator   | events, events-reconcile                           |

---

## 2. Sự kiện đồng bộ (Events)

### GET `/api/events`

Lấy danh sách audit log các sự kiện đồng bộ giữa OpenMetadata và Apache Ranger.

**Query Parameters:**

| Tham số          | Kiểu   | Bắt buộc | Mô tả                                                        |
|------------------|--------|----------|---------------------------------------------------------------|
| `entity_type`    | string | ❌       | Lọc theo loại entity: `created`, `updated`, `deleted`          |
| `event_type`     | string | ❌       | Lọc theo loại event: `table`, `tag`                            |
| `sync_type`      | string | ❌       | Lọc theo loại sync: `webhook`, `reconcile`                     |
| `status`         | string | ❌       | Lọc theo trạng thái: `success`, `running`                      |
| `sync_time_from` | string | ❌       | Lọc từ thời gian sync (ISO 8601, ví dụ `2026-03-28`)          |
| `sync_time_to`   | string | ❌       | Lọc đến thời gian sync (ISO 8601, ví dụ `2026-03-28T23:59:59Z`) |
| `page`           | number | ❌       | Số trang (mặc định: `1`)                                      |
| `pageSize`       | number | ❌       | Số bản ghi mỗi trang (mặc định: `10`)                         |

**Ví dụ request:**
```
GET /api/events?sync_type=webhook&status=success&page=1&pageSize=10
```

**Response (200):**

```json
{
  "data": [
    {
      "id": 1,
      "event_id": "EVT-001",
      "entity_type": "created",
      "event_type": "table",
      "sync_type": "webhook",
      "event_time": "2026-03-28T08:12:00Z",
      "sync_time": "2026-03-28T08:12:05Z",
      "status": "success"
    }
  ],
  "page": 1,
  "pageSize": 10,
  "totalRecords": 12,
  "totalPages": 2
}
```

**Cấu trúc bản ghi Event:**

| Trường        | Kiểu   | Mô tả                                          |
|---------------|--------|-------------------------------------------------|
| `id`          | number | ID nội bộ                                       |
| `event_id`    | string | Mã sự kiện (VD: `EVT-001`)                     |
| `entity_type` | string | Loại entity: `created`, `updated`, `deleted`     |
| `event_type`  | string | Loại event: `table`, `tag`                       |
| `sync_type`   | string | Phương thức đồng bộ: `webhook`, `reconcile`      |
| `event_time`  | string | Thời điểm xảy ra event (ISO 8601)              |
| `sync_time`   | string | Thời điểm hoàn tất đồng bộ (ISO 8601)          |
| `status`      | string | Trạng thái: `success`, `running`                 |

---

## 3. Đối soát dữ liệu (Metadata Reconcile)

### GET `/api/metadata-reconcile`

Lấy danh sách các job đối soát dữ liệu giữa OpenMetadata và Apache Ranger. Trường `metadata` **không** trả về trong API danh sách — dùng API riêng để lấy metadata theo `id`.

**Query Parameters:**

| Tham số         | Kiểu   | Bắt buộc | Mô tả                                                  |
|-----------------|--------|----------|---------------------------------------------------------|
| `status`        | string | ❌       | Lọc theo trạng thái: `success`, `failed`, `running`     |
| `is_matched`    | string | ❌       | Lọc kết quả khớp: `true` (khớp), `false` (lệch)        |
| `job_time_from` | string | ❌       | Lọc từ thời gian job (ISO 8601)                          |
| `job_time_to`   | string | ❌       | Lọc đến thời gian job (ISO 8601)                         |
| `page`          | number | ❌       | Số trang (mặc định: `1`)                                |
| `pageSize`      | number | ❌       | Số bản ghi mỗi trang (mặc định: `10`)                   |

**Ví dụ request:**
```
GET /api/metadata-reconcile?status=failed&is_matched=false&page=1&pageSize=10
```

**Response (200):**

```json
{
  "data": [
    {
      "id": 3,
      "job_time": "2026-03-28T10:00:00Z",
      "duration": 180,
      "status": "failed",
      "job_type": "schedule",
      "is_matched": false,
      "sync_mismatch_duration": 45,
      "sync_mismatch_status": "failed"
    }
  ],
  "page": 1,
  "pageSize": 10,
  "totalRecords": 3,
  "totalPages": 1
}
```

**Cấu trúc bản ghi Metadata Reconcile (danh sách):**

| Trường                   | Kiểu    | Mô tả                                            |
|--------------------------|---------|---------------------------------------------------|
| `id`                     | number  | ID nội bộ                                         |
| `job_time`               | string  | Thời điểm chạy job (ISO 8601)                    |
| `duration`               | number  | Thời lượng chạy (giây)                            |
| `status`                 | string  | Trạng thái: `success`, `failed`, `running`        |
| `job_type`               | string  | Loại job: `schedule` (tự động), `manual` (thủ công) |
| `is_matched`             | boolean | Kết quả khớp: `true` = khớp, `false` = lệch      |
| `sync_mismatch_duration` | number  | Thời lượng lệch (giây), `0` nếu khớp             |
| `sync_mismatch_status`   | string  | Trạng thái sync mismatch: `success`, `failed`, `running` |

---

### GET `/api/metadata-reconcile/:id/metadata`

Lấy chi tiết metadata (danh sách dữ liệu lệch) của một job đối soát cụ thể.

**Path Parameters:**

| Tham số | Kiểu   | Mô tả          |
|---------|--------|-----------------|
| `id`    | number | ID của job      |

**Ví dụ request:**
```
GET /api/metadata-reconcile/3/metadata
```

**Response (200):**

```json
{
  "id": 3,
  "metadata": [
    {
      "type": "table",
      "table": "db.schema.orders",
      "columns": "price,qty",
      "tag": "PII"
    },
    {
      "type": "tag",
      "table": "db.schema.users",
      "columns": "email",
      "tag": "Sensitive"
    }
  ]
}
```

**Cấu trúc object Metadata:**

| Trường    | Kiểu   | Mô tả                                                  |
|-----------|--------|---------------------------------------------------------|
| `type`    | string | Loại mismatch: `table`, `tag`, `columns`                |
| `table`   | string | Tên bảng đầy đủ (VD: `db.schema.orders`)               |
| `columns` | string | Danh sách cột bị lệch, phân tách bằng dấu phẩy         |
| `tag`     | string | Tag liên quan                                            |

> **Lưu ý:** Khi job chưa có dữ liệu lệch (is_matched = true), `metadata` trả về mảng rỗng `[]`.

---

### POST `/api/metadata-reconcile/force`

Kích hoạt force đối soát dữ liệu thủ công.

**Request Body:** Không yêu cầu

**Response (200):**
```json
{
  "message": "Force đối soát thành công"
}
```

---

## 4. Đối soát sự kiện (Events Reconcile)

### GET `/api/events-reconcile`

Lấy danh sách kết quả đối soát sự kiện giữa OpenMetadata và Apache Ranger. Trường `metadata` **không** trả về trong API danh sách — dùng API riêng để lấy metadata theo `id`.

**Query Parameters:**

| Tham số         | Kiểu   | Bắt buộc | Mô tả                                                  |
|-----------------|--------|----------|---------------------------------------------------------|
| `status`        | string | ❌       | Lọc theo trạng thái: `running`, `success`                |
| `is_matched`    | string | ❌       | Lọc kết quả khớp: `true` (khớp), `false` (lệch)        |
| `job_time_from` | string | ❌       | Lọc từ thời gian job (ISO 8601)                          |
| `job_time_to`   | string | ❌       | Lọc đến thời gian job (ISO 8601)                         |
| `page`          | number | ❌       | Số trang (mặc định: `1`)                                |
| `pageSize`      | number | ❌       | Số bản ghi mỗi trang (mặc định: `10`)                   |

**Ví dụ request:**
```
GET /api/events-reconcile?status=success&page=1&pageSize=10
```

**Response (200):**

```json
{
  "data": [
    {
      "id": 1,
      "job_time": "2026-03-28T06:00:00Z",
      "duration": 85,
      "status": "success",
      "job_type": "schedule",
      "is_matched": true
    }
  ],
  "page": 1,
  "pageSize": 10,
  "totalRecords": 10,
  "totalPages": 1
}
```

**Cấu trúc bản ghi Events Reconcile (danh sách):**

| Trường       | Kiểu           | Mô tả                                            |
|--------------|----------------|---------------------------------------------------|
| `id`         | number         | ID nội bộ                                         |
| `job_time`   | string         | Thời điểm chạy job (ISO 8601)                    |
| `duration`   | number         | Thời lượng chạy (giây)                            |
| `status`     | string         | Trạng thái: `running`, `success`                   |
| `job_type`   | string         | Loại job: `schedule` (tự động), `manual` (thủ công) |
| `is_matched` | boolean\|null  | Kết quả khớp: `true` = khớp, `false` = lệch, `null` = đang chạy |

---

### GET `/api/events-reconcile/:id/metadata`

Lấy metadata log của một job đối soát sự kiện cụ thể. Metadata là chuỗi log nhiều dòng (dạng audit log).

**Path Parameters:**

| Tham số | Kiểu   | Mô tả          |
|---------|--------|-----------------|
| `id`    | number | ID của job      |

**Ví dụ request:**
```
GET /api/events-reconcile/3/metadata
```

**Response (200):**

```json
{
  "id": 3,
  "metadata": "[2026-03-28 10:01:12] ERROR: EVT-003 table.deleted - Ranger policy not found for entity \"db.schema.table_1\"\n[2026-03-28 10:02:45] ERROR: EVT-010 table.deleted - Timeout syncing to Ranger after 30s\n[2026-03-28 10:02:46] INFO: Reconcile completed with 2 mismatches"
}
```

**Chi tiết response:**

| Trường     | Kiểu   | Mô tả                                                                  |
|------------|--------|-------------------------------------------------------------------------|
| `id`       | number | ID của job                                                              |
| `metadata` | string | Chuỗi log nhiều dòng (multi-line). Rỗng `""` khi không có log          |

> **Lưu ý:** Khi `status = running`, `is_matched = null` và `metadata` là chuỗi rỗng.

---

### POST `/api/events-reconcile/force`

Kích hoạt force đối soát sự kiện thủ công.

**Request Body:** Không yêu cầu

**Response (200):**
```json
{
  "message": "Đã gửi yêu cầu force đối soát thành công"
}
```

---

## 5. Cấu trúc phân trang chung

Tất cả các API `GET` danh sách đều hỗ trợ phân trang server-side với cấu trúc response thống nhất:

**Request Parameters:**

| Tham số    | Kiểu   | Mặc định | Mô tả                 |
|------------|--------|----------|------------------------|
| `page`     | number | `1`      | Trang hiện tại         |
| `pageSize` | number | `10`     | Số bản ghi mỗi trang  |

**Response bọc ngoài:**

| Trường         | Kiểu   | Mô tả                              |
|----------------|--------|-------------------------------------|
| `data`         | array  | Mảng bản ghi của trang hiện tại    |
| `page`         | number | Trang hiện tại                     |
| `pageSize`     | number | Số bản ghi mỗi trang              |
| `totalRecords` | number | Tổng số bản ghi (sau khi lọc)     |
| `totalPages`   | number | Tổng số trang                      |

---

## 6. Mã trạng thái HTTP

| Mã  | Ý nghĩa                                    |
|-----|---------------------------------------------|
| 200 | Thành công                                  |
| 400 | Request không hợp lệ (thiếu/sai tham số)   |
| 401 | Chưa xác thực (token thiếu hoặc hết hạn)   |
| 403 | Không có quyền truy cập                     |
| 404 | Không tìm thấy tài nguyên                  |
| 500 | Lỗi server                                  |

---

> **Ghi chú:** Tất cả thời gian sử dụng định dạng **ISO 8601** (UTC). Frontend hiển thị theo timezone `vi-VN`.
