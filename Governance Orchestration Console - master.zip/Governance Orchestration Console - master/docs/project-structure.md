# Cấu trúc dự án — Governance Orchestration Console

## Tổng quan

**Governance Orchestration Console** là ứng dụng web quản trị frontend, dùng để giám sát và quản lý việc đồng bộ metadata/tag giữa **OpenMetadata** và **Apache Ranger**. Dự án được xây dựng với React 19, Vite 8, Tailwind CSS 4 và sử dụng MSW (Mock Service Worker) để giả lập API trong môi trường phát triển.

---

## Công nghệ sử dụng

| Thành phần       | Công nghệ                     | Phiên bản  |
| ---------------- | ----------------------------- | ---------- |
| Framework UI     | React                         | 19.x       |
| Build tool       | Vite                          | 8.x        |
| CSS Framework    | Tailwind CSS                  | 4.x        |
| Routing          | React Router DOM              | 7.x        |
| Mock API         | MSW (Mock Service Worker)     | 2.x        |
| Design tokens    | Material Design 3 (custom)    |            |
| Font             | Inter (Google Fonts)          |            |
| Icon             | Material Symbols Outlined     |            |
| Ngôn ngữ giao diện | Tiếng Việt                 |            |

---

## Cây thư mục

```
Governance Orchestration Console/
│
├── _bmad/                          # Cấu hình BMAD workflow engine
│   ├── _config/                    # Agent, skill, manifest config
│   ├── bmm/                        # BMAD Method Module (phân tích → triển khai)
│   ├── cis/                        # Creative & Innovation Skills
│   ├── core/                       # Core skills (brainstorming, review, ...)
│   └── tea/                        # Test Engineering Architecture
│
├── _bmad-output/                   # Sản phẩm đầu ra của BMAD workflow
│   ├── planning-artifacts/         # PRD, epics & stories, sprint progress
│   ├── implementation-artifacts/   # (Dự trữ cho deployment outputs)
│   └── test-artifacts/             # (Dự trữ cho test reports)
│
├── docs/                           # Tài liệu dự án
│   ├── api-documentation.md        # Tài liệu API chi tiết (tiếng Việt)
│   └── project-structure.md        # Tài liệu cấu trúc dự án (file này)
│
├── src/                            # ===== FRONTEND APPLICATION =====
│   ├── index.html                  # Entry HTML (load font Inter, Material Symbols)
│   ├── package.json                # Dependencies & scripts
│   ├── vite.config.js              # Cấu hình Vite (React + Tailwind plugins)
│   ├── eslint.config.js            # ESLint rules
│   │
│   ├── public/                     # Static assets
│   │   ├── favicon.svg
│   │   ├── icons.svg
│   │   └── mockServiceWorker.js    # MSW service worker (auto-generated)
│   │
│   └── src/                        # ===== SOURCE CODE =====
│       ├── main.jsx                # Entry point — khởi tạo React DOM & MSW worker
│       ├── App.jsx                 # Router chính — protected routes, permission routing
│       ├── App.css                 # (Placeholder, styles dùng Tailwind)
│       ├── index.css               # Tailwind imports + Material Design 3 color theme
│       │
│       ├── config/                 # Cấu hình ứng dụng
│       │   └── modules.js          # Module registry (đăng ký module mới tại đây)
│       │
│       ├── contexts/               # React Context
│       │   └── AuthContext.jsx     # Quản lý auth state (login, logout, permissions)
│       │
│       ├── layouts/                # Layout components
│       │   ├── Layout.jsx          # Layout chính (sidebar + header + content area)
│       │   ├── Header.jsx          # Top bar (thông tin user, logout)
│       │   └── Sidebar.jsx         # Sidebar trái (navigation theo permission)
│       │
│       ├── pages/                  # Trang chức năng
│       │   ├── LoginPage.jsx       # Trang đăng nhập
│       │   ├── EventsPage.jsx      # Sự kiện đồng bộ (audit log)
│       │   ├── ReconcilePage.jsx   # Đối soát dữ liệu (reconcile jobs)
│       │   └── EventsReconcilePage.jsx  # Đối soát sự kiện (+ force đối soát)
│       │
│       ├── mocks/                  # Mock API (MSW)
│       │   ├── browser.js          # MSW browser worker setup
│       │   └── handlers.js         # Mock handlers cho tất cả endpoints
│       │
│       ├── components/             # (Dự trữ cho shared components)
│       ├── services/               # (Dự trữ cho API service layer)
│       └── assets/                 # Hình ảnh, SVG
│           ├── hero.png
│           ├── react.svg
│           └── vite.svg
│
├── .gitignore
└── README.md
```

---

## Chi tiết các thành phần

### 1. Entry Point & Routing

#### `src/src/main.jsx`
- Khởi tạo MSW worker trong môi trường development
- Mount React app vào DOM

#### `src/src/App.jsx`
- Định nghĩa toàn bộ routes dựa trên **module registry**
- Các route wrapper:
  - `ProtectedRoute` — yêu cầu đăng nhập
  - `PermRoute` — yêu cầu quyền truy cập module cụ thể
  - `DefaultRedirect` — redirect tới module đầu tiên user có quyền

### 2. Module Registry (`config/modules.js`)

Tất cả module được đăng ký tập trung tại đây. Mỗi module gồm:

| Thuộc tính   | Mô tả                              |
| ------------ | ----------------------------------- |
| `id`         | Định danh duy nhất                  |
| `path`       | URL path                            |
| `label`      | Tên hiển thị trên sidebar           |
| `icon`       | Material Symbol icon name           |
| `component`  | React component (lazy import)       |
| `permission` | Quyền cần có để truy cập            |

**Module hiện tại:**

| Module            | Path                | Mô tả                                    |
| ----------------- | ------------------- | ----------------------------------------- |
| Events            | `/events`           | Audit log sự kiện đồng bộ                |
| Reconcile         | `/reconcile`        | Danh sách job đối soát                    |
| Events Reconcile  | `/events-reconcile` | Kết quả đối soát sự kiện + force đối soát |

> **Để thêm module mới**: Chỉ cần thêm object vào mảng trong `modules.js`. Sidebar, routing, và permission check sẽ tự động cập nhật.

### 3. Xác thực & Phân quyền (`contexts/AuthContext.jsx`)

- Sử dụng React Context API
- Hook `useAuth()` cung cấp:
  - `user` — thông tin user hiện tại
  - `token` — JWT token (mock)
  - `isAuthenticated` — trạng thái đăng nhập
  - `login(username, password)` — đăng nhập
  - `logout()` — đăng xuất
  - `hasPermission(permissionId)` — kiểm tra quyền
- Token và user info lưu trong `localStorage`

**Tài khoản mock:**

| Username  | Password  | Vai trò   | Quyền                                  |
| --------- | --------- | --------- | --------------------------------------- |
| `admin`   | `admin`   | Admin     | Tất cả module                           |
| `viewer`  | `viewer`  | Viewer    | Chỉ xem Events                         |
| `operator`| `operator`| Operator  | Events + Reconcile                      |

### 4. Layout System

```
┌──────────────────────────────────────────────────┐
│                    Header.jsx                     │
│  [☰ Menu]        Governance Console    [User ▼]  │
├──────────┬───────────────────────────────────────┤
│          │                                       │
│ Sidebar  │           Content Area                │
│  .jsx    │         (Router Outlet)               │
│          │                                       │
│ - Events │    ┌─────────────────────────────┐    │
│ - Recon  │    │  Page Header                │    │
│ - E.Rec  │    │  Filter Bar                 │    │
│          │    │  Table (scrollable)          │    │
│          │    │  Pagination Footer           │    │
│          │    └─────────────────────────────┘    │
│          │                                       │
└──────────┴───────────────────────────────────────┘
```

- **Layout.jsx**: `h-screen flex flex-col overflow-hidden` — layout full viewport
- **Sidebar**: Responsive — ẩn trên mobile, toggle hamburger menu
- **Content area**: `flex-1 min-h-0 flex flex-col p-6`
- **Page pattern**: Header → Filter → Table (flex-1 overflow-auto, sticky thead) → Pagination

### 5. Các trang chức năng

#### EventsPage — Sự kiện đồng bộ
- **Bộ lọc**: Entity Type, Event Type, Sync Type, Status, Từ ngày, Đến ngày
- **Cột bảng**: Event ID, Entity Type, Event Type, Sync Type, Event Time, Sync Time, Status
- **Phân trang**: Server-side với page/pageSize

#### ReconcilePage — Đối soát dữ liệu
- **Bộ lọc**: Status, Kết quả khớp, Từ ngày, Đến ngày
- **Cột bảng**: Job ID, Thời gian, Thời lượng, Loại, Status, Khớp, Mismatch duration
- **Phân trang**: Server-side

#### EventsReconcilePage — Đối soát sự kiện
- **Bộ lọc**: Status, Kết quả khớp, Từ ngày, Đến ngày
- **Force đối soát**: 2 chế độ
  - *Từ event gần nhất*: Hệ thống tự lấy thời điểm event cuối
  - *Từ thời điểm tự chọn*: Người dùng chọn ngày bắt đầu (datetime-local)
- **Phân trang**: Server-side

### 6. Mock API (`mocks/handlers.js`)

Sử dụng **MSW v2** với API `http` / `HttpResponse`:

| Method | Endpoint                       | Mô tả                           |
| ------ | ------------------------------ | -------------------------------- |
| POST   | `/api/login`                   | Đăng nhập, trả token + role     |
| GET    | `/api/events`                  | Danh sách events (filter + page) |
| GET    | `/api/reconcile`               | Danh sách reconcile jobs         |
| GET    | `/api/events-reconcile`        | Danh sách events reconcile       |
| POST   | `/api/events/force`            | Force sync events                |
| POST   | `/api/events-reconcile/force`  | Force đối soát sự kiện           |

**Tính năng mock:**
- Lọc phía server theo query params
- Phân trang với helper `paginate()` — trả `data`, `page`, `pageSize`, `totalPages`, `totalRecords`
- Dữ liệu mock: 12 events, 10 reconcile jobs, 10 event-reconcile records

### 7. Design System

#### Color Tokens (Material Design 3)

Định nghĩa trong `index.css` qua `@theme`:

| Token                       | Giá trị   | Sử dụng                  |
| --------------------------- | --------- | ------------------------- |
| `--color-primary`           | `#285ab9` | Nút chính, links, active  |
| `--color-primary-dim`       | `#154dac` | Hover state               |
| `--color-on-primary`        | `#f7f7ff` | Text trên primary bg      |
| `--color-surface`           | `#f8f9fb` | Background chính          |
| `--color-on-surface`        | `#2b3438` | Text chính                |
| `--color-error`             | `#9f403d` | Trạng thái lỗi            |

Sử dụng trực tiếp qua Tailwind classes: `bg-primary`, `text-on-primary`, `hover:bg-primary-dim`...

#### Status Colors

| Trạng thái | Màu                                   |
| ---------- | -------------------------------------- |
| success    | `bg-emerald-50 text-emerald-700`       |
| failed     | `bg-red-50 text-red-700`              |
| pending    | `bg-amber-50 text-amber-700`          |
| running    | `bg-blue-50 text-blue-600`            |

---

## Lệnh phát triển

```bash
# Cài đặt dependencies
npm install

# Chạy development server (với MSW mock API)
npm run dev

# Build production
npm run build

# Preview bản build
npm run preview

# Kiểm tra lint
npm run lint
```

---

## Kiến trúc mở rộng

### Thêm module mới

1. **Tạo page component** trong `src/src/pages/NewModulePage.jsx`
2. **Đăng ký module** trong `src/src/config/modules.js`:
   ```js
   {
     id: 'new-module',
     path: '/new-module',
     label: 'Module Mới',
     icon: 'icon_name',
     component: lazy(() => import('../pages/NewModulePage')),
     permission: 'new-module:view'
   }
   ```
3. **Thêm mock handler** trong `src/src/mocks/handlers.js` (nếu cần)
4. **Cập nhật permissions** trong handler `/api/login` cho các roles

→ Sidebar, routing, và permission check tự động hoạt động mà không cần sửa thêm file nào.

### Kết nối API thật

1. Xóa hoặc disable MSW worker trong `main.jsx`
2. Cập nhật URL endpoint trong các page (hoặc tạo API service layer trong `src/src/services/`)
3. Cập nhật `AuthContext.jsx` để dùng token thật từ backend

---

## Thư mục dự trữ (chưa sử dụng)

| Thư mục                                | Mục đích dự kiến                         |
| --------------------------------------- | ---------------------------------------- |
| `src/src/components/`                   | Shared/reusable UI components            |
| `src/src/services/`                     | API client, data fetching hooks          |
| `_bmad-output/implementation-artifacts/`| Deployment outputs, build artifacts      |
| `_bmad-output/test-artifacts/`          | Test reports, coverage                   |
