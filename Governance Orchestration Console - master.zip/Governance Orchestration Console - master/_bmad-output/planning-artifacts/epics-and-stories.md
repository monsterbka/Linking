## Epics & User Stories – Governance Orchestration Console

### Epic 1: Khởi tạo khung dự án & mock API

- **Story 1.1:** Khởi tạo project frontend (chọn framework phù hợp, ví dụ React/Vue/Angular)
- **Story 1.2:** Thiết lập cấu trúc thư mục chuẩn cho dự án
- **Story 1.3:** Thiết lập hệ thống routing, layout tổng thể
- **Story 1.4:** Tích hợp hệ thống mock API (sử dụng thư viện như MSW, MirageJS hoặc tự viết mock trong project, không tạo repo riêng)
- **Story 1.5:** Tạo các endpoint mock cho các module: events, reconcile, events reconcile, login

### Epic 2: Module Đăng nhập (Login)

- **Story 2.1:** Xây dựng giao diện form đăng nhập
- **Story 2.2:** Kết nối với mock API xác thực user
- **Story 2.3:** Xử lý phân quyền cơ bản (ẩn/hiện menu theo quyền user)

### Epic 3: Module Events

- **Story 3.1:** Xây dựng giao diện bảng hiển thị audit log events
- **Story 3.2:** Kết nối bảng với mock API events
- **Story 3.3:** Thêm chức năng filter theo entity_type, event_type, sync_type, status, khoảng thời gian sync_time
- **Story 3.4:** Thêm chức năng reload dữ liệu thủ công

### Epic 4: Module Reconcile

- **Story 4.1:** Xây dựng giao diện bảng hiển thị danh sách job reconcile
- **Story 4.2:** Kết nối bảng với mock API reconcile
- **Story 4.3:** Thêm chức năng filter theo status, is_matched, khoảng thời gian job_time
- **Story 4.4:** Thêm chức năng reload dữ liệu thủ công

### Epic 5: Module Events Reconcile

- **Story 5.1:** Xây dựng giao diện bảng hiển thị danh sách event reconcile
- **Story 5.2:** Kết nối bảng với mock API events reconcile
- **Story 5.3:** Thêm chức năng filter theo status, is_matched, khoảng thời gian job_time
- **Story 5.4:** Thêm chức năng force đối soát (theo thời gian tùy chọn hoặc tự động)
- **Story 5.5:** Thêm chức năng reload dữ liệu thủ công

### Epic 6: Chuẩn bị cho mở rộng module mới

- **Story 6.1:** Thiết kế cấu trúc code và mock API dễ mở rộng cho các module mới

---
**Lưu ý:**
- Tất cả các API đều cần mock trực tiếp trong project cho đến khi backend sẵn sàng.
- Ưu tiên build khung dự án, layout, mock API trước, sau đó phát triển từng module theo thứ tự ưu tiên.