## Product Requirements Document (PRD) – Governance Orchestration Console

### 1. Mục tiêu sản phẩm
Xây dựng một trang admin quản trị tập trung cho team Governance (và các user được phân quyền) để giám sát, quản lý đồng bộ tags/metadata giữa OpenMetadata và Apache Ranger.

### 2. Đối tượng người dùng
- Thành viên team Governance.
- Các user được phân quyền truy cập.

### 3. Chức năng chính
- Đăng nhập (login) xác thực người dùng.
- Hiển thị, lọc, giám sát các audit log events (module events).
- Theo dõi, kiểm soát các job reconcile (module reconcile).
- Theo dõi, xử lý các event reconcile (module events reconcile).
- Giao diện hiển thị dữ liệu dạng bảng (table) cho tất cả các module.
- Cho phép reload dữ liệu thủ công (không cần realtime).
- Dễ dàng mở rộng thêm module mới trong tương lai.

### 4. Yêu cầu giao diện
- Đơn giản, tập trung vào hiển thị bảng dữ liệu.
- Không cần theme dark/light, không cần đa ngôn ngữ.

### 5. Yêu cầu kỹ thuật
- Frontend kết nối với backend qua các API đã có sẵn.
- Hỗ trợ phân quyền truy cập theo user.
- Không cần chức năng export dữ liệu.

### 6. Mô tả chi tiết các module

#### 6.1. Module Events
- Hiển thị danh sách các audit log events với các trường: id, event_id, entity_type, event_type, sync_type, event_time, sync_time, status, ...
- Hỗ trợ filter theo entity_type, event_type, sync_type, status, khoảng thời gian sync_time.

#### 6.2. Module Reconcile
- Hiển thị danh sách các job reconcile với các trường: id, job_time, duration, status, job_type, is_matched, sync_mismatch_duration, ...
- Hỗ trợ filter theo status, is_matched, khoảng thời gian job_time.

#### 6.3. Module Events Reconcile
- Hiển thị danh sách các event reconcile với các trường: id, job_time, duration, status, job_type, is_matched, ...
- Hỗ trợ filter theo status, is_matched, khoảng thời gian job_time.
- Có chức năng force đối soát theo thời gian tùy chọn hoặc tự động theo event_time cuối cùng.